/**
 * @file: odom_pub_node.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "ros/ros.h"

#include <iostream>
#include <stdint.h>
#include <math.h>
#include <string>
#include <csignal>
#include <cstdio>

#include <can_to_eth/c2e.h>
#include <can_to_eth/can_data.h>
#include <tf/transform_broadcaster.h>


#include "std_msgs/UInt32.h"
#include <nav_msgs/Odometry.h>

//----------z.h--------------------//
//Transform the coordinate system from IMU installation position to vehicle front axle center
//#define TRANS_X -57291.78 - 2
#define TRANS_X -0.595
//#define TRANS_Y 4453577.394 -3
#define TRANS_Y -0.108
//----------z.h-------------------//


ODOM_PUB::ODOM_PUB() 
{
}

ODOM_PUB::~ODOM_PUB()
{
}

void ODOM_PUB::ParseData(CAN_MESSAGE &canmessge)
{
    CAN_STRUCT Temp_can;
    int t_state,t_heading,t_temp;
    long t_latitude,t_logitude;

    Temp_can.can_info = canmessge.can_data[0];
    Temp_can.can_id = 0;
    for(int i=1;i<5;i++)
    {
        Temp_can.can_id <<= 8;
        Temp_can.can_id |= canmessge.can_data[i];
    }
    //ROS_INFO("[Z.H]IPC parses the data sent by the bottom CAN, and can_id is: %#X",Temp_can.can_id);

    for(int i=0;i<8;i++)
    {
        Temp_can.can_data[i] = canmessge.can_data[i+5];
    }

    /*
    for(int i=0;i<8;i++)
    {
        ROS_INFO("canmessge: %d",Temp_can.can_data[i]);
    }
    */  
    switch(Temp_can.can_id)
    {
        case 0x40b:
            t_heading = 0;
            gps_state = Temp_can.can_data[3];
            t_heading = (((int)Temp_can.can_data[2])<<8) | Temp_can.can_data[1] ;
            vel_heading = (double)t_heading/100 ;
            ROS_INFO("[Z.H]PARSE 0x40B: gps_state:%0X; vel_heading: %.3f", gps_state, vel_heading);
            GPSAliveTime = ros::Time::now();
            break;

        case 0x30b:
            t_latitude = 0;
            for(int i=3;i>=0;i--)
            {
                t_latitude <<= 8;
                t_latitude |= Temp_can.can_data[i];
            }
            vel_position_x = t_latitude;
            t_logitude = 0;
            for(int i=7;i>3;i--)
            {
                t_logitude <<= 8;
                t_logitude |= Temp_can.can_data[i];
            }
            vel_position_y = t_logitude;
            ROS_INFO("[Z.H]PARSE 0x30B: t_latitude: %ld, t_logitude: %ld",t_latitude,t_logitude);
            GPSAliveTime = ros::Time::now();

            // low prass filter
            static double last_x = 0;
            static double last_y = 0;
            vel_position_x = filter_rate0 * last_x + (1-filter_rate0) * vel_position_x;
            vel_position_y = filter_rate0 * last_y + (1-filter_rate0) * vel_position_y;
            last_x = vel_position_x;
            last_y = vel_position_y;

            static double llast_x = 0;
            static double llast_y = 0;
            vel_position_x = filter_rate1 * llast_x + (1-filter_rate1) * vel_position_x;
            vel_position_y = filter_rate1 * llast_y + (1-filter_rate1) * vel_position_y;
            llast_x = vel_position_x;
            llast_y = vel_position_y;

            break;

        case 0x91:
            // bottom feedback signal
            current_driving_mode = (uint8_t)(Temp_can.can_data[0] & 0x0f);//0 hand 1 auto
            enable_switch = (uint8_t)((Temp_can.can_data[0] & 0x10) >> 4);//hardware switch 0 invalid 1 enable
            stop_switch = (uint8_t)((Temp_can.can_data[0] & 0x20) >> 5);//0 enable 1 invalid
            current_driving_state = (int8_t)(Temp_can.can_data[1]);//-100
            gear_feedback = (uint8_t)(Temp_can.can_data[2] & 0x0f);// 1 N 2 D 3 R
            bottom_heart = (uint8_t)(Temp_can.can_data[7]);
            car_counter += bottom_heart;
            if(car_counter > 255)
                car_counter = 0;

            t_temp = (((int)Temp_can.can_data[3]<<8) | Temp_can.can_data[4]) ;
            vel_speed =  ((double)t_temp)/256/3.6;// m/s
            static double vel_filtered = 0;
            vel_speed = 0.1 * vel_speed + 0.9 * vel_filtered;
            vel_filtered = vel_speed;
            current_steering_angle = ((double)((Temp_can.can_data[5]<<8) | Temp_can.can_data[6]))/16-2048;// degree
            ROS_INFO_STREAM("[Z.H]PARSE 0x91:\n" 
                      << " 1.current_driving_mode: " << current_driving_mode << ";\n"
                      << " 2.enable_switch: " << enable_switch << "; \n"
                      << " 3.stop_switch: " <<  stop_switch << "; \n"
                      << " 4.current_driving_state: " << current_driving_state << "; \n"
                      << " 5.gear_feedback: " << gear_feedback << "; \n"
                      << " 6.bottom_heart: " << bottom_heart
                      << " 7.vel_speed: " << vel_speed*3.6 << " km/h; \n"
                      << " 8.feedback_steering_angle: " << current_steering_angle << " degree.");
            break;
    }    
}


void ODOM_PUB::pub_cmd_down(void)
{
    static unsigned int counter = 0;
    can_to_eth::can_data pub_data;

    counter++;  

    //PID_params_change();
    //0x0500
    memset(&pub_data.can_data[0],0,13);

    pub_data.can_data[0] = 8;
    pub_data.can_data[1] = 0;
    pub_data.can_data[2] = 0;
    pub_data.can_data[3] = 0x05;
    pub_data.can_data[4] = 0x00;
    /*
    uint8_t gear_targetWorkMode = static_cast<uint8_t>(static_cast<uint8_t>(((gear_cmd & 0x03) << 2) | (targetWorkMode & 0x03)) & 0x0f);
    if(full_stop_flag == 1)
    {
      pub_data.can_data[5] = static_cast<uint8_t>(static_cast<uint8_t>(0x10 | gear_targetWorkMode) & 0x1f);//cmd_set 0 hand 2 AD // 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
    }
    else
    {
      pub_data.can_data[5] = static_cast<uint8_t>(gear_targetWorkMode & 0x0f);//cmd_set 0 hand 2 AD // 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
    }
    */
    
    if(full_stop_flag == 1)
    {
      pub_data.can_data[5] = static_cast<uint8_t>(static_cast<uint8_t>(0x10 | targetWorkMode) & 0x13);//cmd_set 0 hand 2 AD // 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
    }
    else
    {
      pub_data.can_data[5] = static_cast<uint8_t>(targetWorkMode & 0x03);//cmd_set 0 hand 2 AD // 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
    }
    
    pub_data.can_data[6] = static_cast<uint8_t>((static_cast<uint16_t>((targetSpeed+5000)*10) >>8) & 0xff);
    pub_data.can_data[7] = static_cast<uint8_t>(static_cast<uint16_t>((targetSpeed+5000)*10) & 0xff);
    pub_data.can_data[8] = static_cast<uint8_t>((static_cast<int16_t>((targetSteeringAngle+2048)*16) >>8) & 0xff);
    pub_data.can_data[9] = static_cast<uint8_t>(static_cast<int16_t>((targetSteeringAngle+2048)*16) & 0xff);
    pub_data.can_data[10]= static_cast<uint8_t>(static_cast<uint16_t>(targetSteeringVelocity/4) & 0xff);
    pub_data.can_data[11]= static_cast<uint8_t>(static_cast<uint16_t>(counter) & 0xff);
    pub_data.can_data[12]= static_cast<uint8_t>(static_cast<uint16_t>(flag_use_ros_pidparams) & 0xff);
    
    can_pub.publish(pub_data);
    ROS_INFO_STREAM("[Z.H]IPC will send PID info to the bottom CAN are:\n"
                   <<"[0X0500]: \n"
                   << "0.full_stop_flag: " << full_stop_flag << " \n"
                   << "1.gear_cmd: " << gear_cmd << " \n"
                   << "2.targetWorkMode: " << targetWorkMode << "; \n"
                   << "3.targetSpeed: " << targetSpeed << " km/h" << "; \n"
                   << "4.targetSteeringAngle: " << targetSteeringAngle << " degree; \n"
                   << "5.targetSteeringVelocity: " << targetSteeringVelocity << " degree/s; \n"
                   << "6.ros heart: " << counter << "; \n"
                   << "7.flag_use_ros_pidparams: " << flag_use_ros_pidparams);
    // 0x04FF
    memset(&pub_data.can_data[0],0,13);

    pub_data.can_data[0] = 8;
    pub_data.can_data[1] = 0;
    pub_data.can_data[2] = 0;
    pub_data.can_data[3] = 0x04;
    pub_data.can_data[4] = 0xff;

    pub_data.can_data[5] = static_cast<uint8_t>(static_cast<uint16_t>(brake_kp*50) & 0xff);//max 5.1
    pub_data.can_data[6] = static_cast<uint8_t>(static_cast<uint16_t>(brake_ki*25) & 0xff);//max 1
    pub_data.can_data[7] = static_cast<uint8_t>(static_cast<uint16_t>(vcu_kp*5) & 0xff);//max 51
    pub_data.can_data[8] = static_cast<uint8_t>(static_cast<uint16_t>(vcu_ki*100) & 0xff);//max 2.5
    pub_data.can_data[9] = static_cast<uint8_t>(static_cast<uint16_t>(brake_min_output) & 0xff);// max 255
    pub_data.can_data[10] = static_cast<uint8_t>(static_cast<uint16_t>(brake_speed_error*500) & 0xff);//max 0.5
    pub_data.can_data[11] = static_cast<uint8_t>(static_cast<uint16_t>(brake_speed_limit*100) & 0xff);//max 2.5
    pub_data.can_data[12] = static_cast<uint8_t>(static_cast<uint16_t>(vcu_speed_limit*100) & 0xff);//max 2.5

    can_pub.publish(pub_data);
    
    counter %= 255;   
}

void ODOM_PUB::pub_set_up(void)
{
    std_msgs::Float64MultiArray decision_msg;
    decision_msg.data.clear();
    decision_msg.data.push_back(current_steering_angle);
    decision_msg.data.push_back(current_driving_state);
    decision_msg.data.push_back(enable_switch);
    decision_msg.data.push_back(current_driving_mode);
    decision_pub.publish(decision_msg);
}

void ODOM_PUB::pub_odom(void)
{
    
    double x = 0; 
    double y = 0;
    double th = 0;
    
    double vx = vel_speed;  
    double vy = 0;
    double vth = 0;
    
    gaussConvert(x,y);

    th = vel_heading;
    geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(th*M_PI/180);
    
    //Transform the coordinate system from IMU installation position to vehicle front axle center
    x += TRANS_X;//Unit m // left + right -
    y += TRANS_Y;
    ROS_INFO("[Z.H]ODOM: IPC receive IMU info from can and trans to front axle center are:\nLON: %.3f LAT: %.3f, Heading: %.3f", x, y, vel_heading);

    //publish odom msg
  	nav_msgs::Odometry odom;
  	odom.header.stamp = ros::Time::now();
  	odom.header.frame_id = "odom";
  	odom.child_frame_id = "base_link";
  	    
  	odom.pose.pose.position.x = x;
  	odom.pose.pose.position.y = y;
  	odom.pose.pose.position.z = gps_state;
    odom.pose.pose.orientation = odom_quat;
  	odom.twist.twist.linear.x = vx;
  	odom.twist.twist.linear.y = gear_feedback;
  	odom.twist.twist.linear.z = 0.0;
  	odom.twist.twist.angular.x = 0.0;
  	odom.twist.twist.angular.y = 0.0;
  	odom.twist.twist.angular.z = vth;

  	odom_pub.publish(odom);
}


void velcmd_Callback(const std_msgs::Float64MultiArray::ConstPtr& msg, ODOM_PUB *cmd_rev)
{
    double Temp_cmd[9];

    for(int i=0;i<9;i++)      
        Temp_cmd[i] = msg->data[i];
    /**
     *@brief: only when both GPS and Lidar are good, the targetWorkMode = 2 
     *@param: 0 no GPS / 1 follow roadmap i.e:GPS is good / 2  lidar is good and gps is good
     */
    unsigned int temp_mode = (unsigned int)Temp_cmd[0];
    if(temp_mode == 1 || temp_mode == 0)  temp_mode = 0;
    cmd_rev->targetWorkMode = temp_mode;
    cmd_rev->targetSpeed = (double)(Temp_cmd[1]*3.6);// unit:km/h
    cmd_rev->targetSteeringAngle = (double)Temp_cmd[2]; 
    cmd_rev->targetSteeringVelocity = (double)Temp_cmd[3];
    cmd_rev->full_stop_flag = (bool)Temp_cmd[4];
    cmd_rev->gear_cmd = (unsigned int)Temp_cmd[5];
    cmd_rev->y_ui = 0;
    cmd_rev->targetBrakePressure = 0;

    cmd_rev->cmdReceivedTime = ros::Time::now();
}




void CanRec_Callback(const can_to_eth::can_data::ConstPtr &msg,ODOM_PUB *port)
{
    can_to_eth::can_data temp_tx_canmessge = *msg;
    CAN_MESSAGE temp_canmessge;
    memcpy(temp_canmessge.can_data,(unsigned char*)&temp_tx_canmessge,13);
    port->can_Rmessage.push_back(temp_canmessge);
}

void lidarHeartCallback(const std_msgs::UInt32::ConstPtr& msg_ptr, ODOM_PUB* cmd_rev_ptr)
{
    static int last_heart_beat = 0;
    cmd_rev_ptr->lidar_status = 1;
    cmd_rev_ptr->heart_count = msg_ptr->data;
    if(cmd_rev_ptr->heart_count == last_heart_beat)
    {
        cmd_rev_ptr->lidar_status = 0;
    }
    else
    {
        cmd_rev_ptr->lidarAliveTime = ros::Time::now();
    }
    cmd_rev_ptr->lidarReceivedTime = ros::Time::now();
    last_heart_beat = cmd_rev_ptr->heart_count;
}

void carStatusCheck(ODOM_PUB* cmd_rev_ptr)
{
    static int last_car_counter = 0;
    cmd_rev_ptr->car_status = 1;
    if(cmd_rev_ptr->car_init == 0)
    {
        cmd_rev_ptr->carAliveTime = ros::Time::now();
        cmd_rev_ptr->car_init = 1;
    }

    if(cmd_rev_ptr->car_counter == last_car_counter)
    {
        cmd_rev_ptr->car_status = 0;
    }
    else
    {
        cmd_rev_ptr->carAliveTime = ros::Time::now();
    }
    cmd_rev_ptr->carReceivedTime = ros::Time::now();
    last_car_counter = cmd_rev_ptr->car_counter;
}

void ODOM_PUB::set_params(ros::NodeHandle nh)
{
    ROS_INFO("[Z.H] now begin to set odom_pub_node params ~~");

    nh.param("brake_kp", brake_kp, double(0));
    ros::param::get("~brake_kp",brake_kp);
    nh.param("brake_ki", brake_ki, double(0));
    ros::param::get("~brake_ki",brake_ki);

    nh.param("vcu_kp", vcu_kp, double(0));
    ros::param::get("~vcu_kp",vcu_kp);
    nh.param("vcu_ki", vcu_ki, double(0));
    ros::param::get("~vcu_ki",vcu_ki);

    nh.param("brake_min_output", brake_min_output, double(0));
    ros::param::get("~brake_min_output",brake_min_output);
    nh.param("brake_speed_error", brake_speed_error, double(0));
    ros::param::get("~brake_speed_error",brake_speed_error);
    nh.param("brake_speed_limit", brake_speed_limit, double(0));
    ros::param::get("~brake_speed_limit",brake_speed_limit);

    nh.param("vcu_speed_limit", vcu_speed_limit, double(0));
    ros::param::get("~vcu_speed_limit",vcu_speed_limit);

    nh.param("flag_use_ros_pidparams", flag_use_ros_pidparams, true);
    ros::param::get("~flag_use_ros_pidparams",flag_use_ros_pidparams);


    ROS_INFO_STREAM("[Z.H]load launch file PID params are:\n"
                << "1.brake_kp:" << brake_kp << "; "
                << "2.brake_ki:" << brake_ki << "; "
                << "3.vcu_kp:" << vcu_kp << "; "
                << "4.vcu_ki:" << vcu_ki << "; "
                << "5.brake_min_output:" << brake_min_output << "; "
                << "6.brake_speed_error:" << brake_speed_error << "; "
                << "7.brake_speed_limit:" << brake_speed_limit << "; "
                << "8.vcu_speed_limit:" << vcu_speed_limit << "; "
                << "9.flag_use_ros_pidparams:" << flag_use_ros_pidparams);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "vehicle_ctrl");
    ODOM_PUB vel_ctrl;
    ros::NodeHandle nh;

    vel_ctrl.set_params(nh);

    ros::Subscriber decision_sub = nh.subscribe<std_msgs::Float64MultiArray>("decision_pub", 10,boost::bind(velcmd_Callback,_1,&vel_ctrl));
    ros::Subscriber can_sub1 = nh.subscribe<can_to_eth::can_data>("can2net1", 50, boost::bind(CanRec_Callback,_1,&vel_ctrl));
    ros::Subscriber can_sub2 = nh.subscribe<can_to_eth::can_data>("can2net2", 50, boost::bind(CanRec_Callback,_1,&vel_ctrl));
    ros::Subscriber lidar_heart_sub = nh.subscribe<std_msgs::UInt32>("HeartBeat", 50,boost::bind(lidarHeartCallback,_1,&vel_ctrl));

    vel_ctrl.odom_pub = nh.advertise<nav_msgs::Odometry>("odom", 10);
    vel_ctrl.decision_pub =nh.advertise<std_msgs::Float64MultiArray>("decision_sub", 10);
    vel_ctrl.can_pub = nh.advertise<can_to_eth::can_data>("net2can", 10);
    
    CAN_MESSAGE temp_canmessge;
    //can_to_eth::can_data temp_rx_canmessge;

    ros::Rate loop_rate(40);
    ros::Time old_time = ros::Time::now();
    vel_ctrl.GPSAliveTime = ros::Time::now();

    while(ros::ok())
    {
        ros::Time now_time = ros::Time::now();
        while(!vel_ctrl.can_Rmessage.empty())
        {
            temp_canmessge = vel_ctrl.can_Rmessage.front();
            //memcpy((unsigned char*)&temp_rx_canmessge,temp_canmessge.can_data,13);
            vel_ctrl.ParseData(temp_canmessge);
            vel_ctrl.can_Rmessage.erase(vel_ctrl.can_Rmessage.begin());
        }

        if((now_time-old_time).toSec() >= 0.05)
        {
            ROS_INFO("[Z.H]now its begin to publish odom/cmd/decision info~~");
            carStatusCheck(&vel_ctrl);
            /*
            if((vel_ctrl.lidar_status == 0||vel_ctrl.lidar_status == 1)
                &&(((ros::Time::now().toSec()-vel_ctrl.lidarReceivedTime.toSec())>1)
                ||(ros::Time::now().toSec()-vel_ctrl.lidarAliveTime.toSec()>1)))
            {
                ROS_ERROR("[Z.H]lidar DIED!!!");
            }
            */

            if((ros::Time::now().toSec()-vel_ctrl.cmdReceivedTime.toSec())>2){
                vel_ctrl.targetWorkMode = 0;
                ROS_ERROR("[Z.H]NO planning_control info received, please check planning_control!!!");
            }
            if((((ros::Time::now().toSec()-vel_ctrl.carReceivedTime.toSec())>5)
                 ||(ros::Time::now().toSec()-vel_ctrl.carAliveTime.toSec()>5)))
            {
                vel_ctrl.targetWorkMode = 0;
                ROS_ERROR("[Z.H]NO bottom feedback info, please check bottom!!!");    
            }

            if((now_time.toSec()-vel_ctrl.GPSAliveTime.toSec())>2)
            {
                vel_ctrl.targetWorkMode = 0;
                ROS_ERROR("[Z.H]NO IMU info, please check IMU!!!");
            }

            vel_ctrl.pub_odom();
            vel_ctrl.pub_cmd_down();
            vel_ctrl.pub_set_up();

            old_time  = now_time;
        }
        ros::spinOnce();
        loop_rate.sleep();    
    }
    return 0;
}
