/**
 * @file: odom_pub_node.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "ros/ros.h"

#include <iostream>
#include <stdint.h>
#include <math.h>
#include <string>
#include <csignal>
#include <cstdio>

#include <can_to_eth/c2e.h>
#include <can_to_eth/can_data.h>

// parameters
std::string host;
int port1,port2;
bool flag_test;

void can_t_Callback(const can_to_eth::can_data::ConstPtr &msg, CAN_ETH *c2e)
{
    can_to_eth::can_data temp_tx_canmessge = *msg;

    CAN_MESSAGE temp_canmessge;
    memcpy(temp_canmessge.can_data,(unsigned char*)&temp_tx_canmessge,13);
    c2e->can_Tmessage.push_back(temp_canmessge);

    ROS_INFO("[Z.H]receive IPC data to be sent into bottom can~");
}

bool can_connect(CAN_ETH& c2e, std::string host, int port)
{
    ROS_INFO_STREAM("[Z.H]now begin to connect to CANET at: " << host << " and its port is:" << port);

    c2e.connect(host, port);
    if(!c2e.isConnected())
    {
        ROS_WARN("[Z.H]now unable to connect to CANET, its port is: %d, retrying...", port);
        ros::Duration(0.5).sleep();
        return 1;
    }
    else
    {
        ROS_INFO("[Z.H]now connecting is success and its port is %d ~~~", port);
        return 0;
    }
}

void set_params(ros::NodeHandle &nh)
{
    ROS_INFO("[Z.H] now begin to set c2e_node params ~~");

    nh.param("host", host, std::string("192.168.0.178"));
    ros::param::get("~host",host);
    
    nh.param("port1", port1, int(4001));
    ros::param::get("~port1",port1);

    nh.param("port2", port2, int(4002));
    ros::param::get("~port2",port2);

    nh.param("flag_test", flag_test, false);
    ros::param::get("~flag_test",flag_test);

    ROS_INFO_STREAM("[Z.H]now set c2e_node params complete, and host:" << host << ";port1:" << port1 << ";port2:" << port2);
}

int main(int argc, char **argv)
{
    CAN_ETH c2e1; // can1
    CAN_ETH c2e2; // can2

    ros::init(argc, argv, "can_to_eth");
    ros::NodeHandle nh;
    set_params(nh);

    ros::Publisher can_pub1 = nh.advertise<can_to_eth::can_data>("can2net1", 10);
    ros::Publisher can_pub2 = nh.advertise<can_to_eth::can_data>("can2net2", 10);
    ros::Subscriber can_sub = nh.subscribe<can_to_eth::can_data>("net2can", 10, boost::bind(can_t_Callback,_1, &c2e1));

    CAN_MESSAGE temp_canmessge;
    can_to_eth::can_data temp_rx_canmessge;

    ros::Rate loop_rate(500);

    while(ros::ok())
    {
        bool flag1,flag2;
        flag1 = can_connect(c2e1,host,port1);
        if(flag1 == 1)
            continue;
        flag2 = can_connect(c2e2,host,port2);
        if(flag2 == 1)
            continue;

        int counter = 0, counter1 = 0, counter2 = 0;
       
        unsigned char test1[13] = {0x08,0x00,0x00,0x03,0x0B,1,2,3,4,5,6,7,8};
        unsigned char test2[13] = {0x08,0x00,0x00,0x04,0x0B,1,2,3,4,5,6,7,8};
        unsigned char test3[13] = {0x08,0x00,0x00,0x00,0x91,1,2,3,4,5,6,7,8};

        while (ros::ok())
        {          
           /**
            // can test
            test[9]++;
            memcpy((unsigned char*)&temp_canmessge, test, 13);
            c2e1.can_Tmessage.push_back(temp_canmessge);
            c2e2.can_Tmessage.push_back(temp_canmessge);
            */


            // can send
            c2e1.sent_to_can();
            c2e2.sent_to_can();

            // can1 receive
            c2e1.receive_from_can();
            while(!c2e1.can_Rmessage.empty())
            {
                temp_canmessge = c2e1.can_Rmessage.front();
                memcpy((unsigned char*)&temp_rx_canmessge,temp_canmessge.can_data,13);
                c2e1.can_Rmessage.erase(c2e1.can_Rmessage.begin());
                can_pub1.publish(temp_rx_canmessge);
                if(flag_test == 1)
                {
                    ROS_INFO("[Z.H]c2e1 receive from the bottom can message is :");
                    for(int i = 0;i < 13;++i)
                    {
                        std::cout << static_cast<uint16_t>(temp_canmessge.can_data[i]) << " ";
                    }
                    std::cout << std::endl;
                    counter1++;
                    if(counter1>10000) counter1 = 0;
                }
            }

            // can2 receive
            c2e2.receive_from_can();
            while(!c2e2.can_Rmessage.empty())
            {
                temp_canmessge = c2e2.can_Rmessage.front();
                memcpy((unsigned char*)&temp_rx_canmessge,temp_canmessge.can_data,13);
                c2e2.can_Rmessage.erase(c2e2.can_Rmessage.begin());
                can_pub2.publish(temp_rx_canmessge);
                if(flag_test == 1)
                {         
                    ROS_INFO("[Z.H]c2e2 receive from the bottom can message is :");
                    for(int i = 0;i < 13;++i)
                    {
                        std::cout << static_cast<uint16_t>(temp_canmessge.can_data[i]) << " ";
                    }
                    std::cout << std::endl;
                    counter2++;
                    if(counter2>10000) counter2 = 0;
                }     
            }

            ros::spinOnce();
            loop_rate.sleep();
            counter++;
            if(counter>10000) counter = 0;
        }
    }
    return 0;
}
