/**
 * @file: planning_control_pub_node.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "planning_control/planning_control.hpp"



int main(int argc, char *argv[])
{
	/**********************load road map************************/
	//load roadpoint and stoppoint 
	std::string path = ros::package::getPath("planning_control");
	std::string roadMap_path = path + "/maps/roadMap.txt";
	std::string stopPoint_path = path + "/maps/stopPoint.txt";
	std::string debug_path = path + "/debug.txt";

	std::vector<RoadPoint> rawRoadPoints;
	loadRoadPoints(roadMap_path, rawRoadPoints);
	ROS_INFO("[Z.H]roadpoint size is:%d", global_roadpoint_size);

	std::vector<RoadPoint> rawStopPoints;
	loadStopPoints(stopPoint_path, rawStopPoints);
	ROS_INFO("[Z.H]stoppoint size is:%d", global_stoppoint_size);

	buildFinalRoadPoints(rawRoadPoints, rawStopPoints);
	ROS_INFO("[Z.H]final roadpoint size is:%d", rawRoadPoints.size());
	ROS_INFO("[Z.H]final roadpoint building done~");

	/***********************ROS initialize**********************/
	ros::init(argc, argv, "planning_control");
	ros::NodeHandle n;

	ros::Time odomReceivedTime;
	ros::Time lidarReceivedTime;
	
	// main command subscriber 
    ros::Subscriber decision_sub = n.subscribe<std_msgs::Float64MultiArray>("decision_sub", 1, boost::bind(&decisionSubCallback, _1, &decisionData));
	ros::Subscriber odom_sub = n.subscribe<nav_msgs::Odometry>("odom", 1, boost::bind(&odomCallback, _1, &postureData, &odomReceivedTime));
	ros::Subscriber grid_sub = n.subscribe<nav_msgs::OccupancyGrid>("gridmap", 1, boost::bind(&gridCallback, _1, &lidarData, &lidarReceivedTime));
	ros::Subscriber left_grid_sub = n.subscribe<nav_msgs::OccupancyGrid>("/left/gridmap", 1, boost::bind(&leftGridCallback, _1, &lidarData));
	ros::Subscriber right_grid_sub = n.subscribe<nav_msgs::OccupancyGrid>("/right/gridmap", 1, boost::bind(&rightGridCallback, _1, &lidarData));

	// main command publisher
	ros::Publisher decision_pub = n.advertise<std_msgs::Float64MultiArray>("decision_pub", 1, true);
	ros::Publisher roadPoint_pub = n.advertise<geometry_msgs::PoseArray>("route", 1, true);
	ros::Publisher past_path_pub = n.advertise<geometry_msgs::PoseArray>("past_path", 1, true);
	ros::Publisher currentPoint_pub = n.advertise<geometry_msgs::PoseArray>("current_point", 1, true);
	ros::Publisher obstacleCell_pub = n.advertise<nav_msgs::GridCells>("/gridCell", 1, true);

	//main loop
	ros::Rate loop_rate(25);
	while(n.ok())
	{
		ROS_INFO("[Z.H]PLANNING CONTROL BEGIN SPINNING~~");
		ros::spinOnce();
		decisionData.currentState = 0;

		//publish roadpoint and past_path
		roadPointPublisher(roadPoint_pub,rawRoadPoints);
		pastPathPublisher(past_path_pub, postureData);
		//getCurrentPoint(-1029007.276, 2984533.902, 359.769, rawRoadPoints, decisionData);
		
		//ensure subscribe to odom and gridmap msg
		if((ros::Time::now().toSec() - odomReceivedTime.toSec()) > 1) {
			postureData.b_isValid = false;
			postureData.imuData.b_isValid = false;
			ROS_ERROR("[Z.H]fail to receive odom msg!!! IMU DIED??");
	    }
	    if((ros::Time::now().toSec() - lidarReceivedTime.toSec()) > 1) {
			lidarData.b_isValid = false;
			ROS_ERROR("[Z.H]fail to receive gridmap msg!!! LIDAR DIED??");
		}

		/******************************MAIN CONTROL*****************************/
		/*------------------LATERAL CONTROL---------------------*/
		if(postureData.b_isValid && postureData.imuData.b_isValid)
		{
			//get current speed
			decisionData.velocity = postureData.imuData.velocity;
			if(decisionData.velocity < 0.2)
				decisionData.velocity = 0;
			// get current point in roadmap
			getCurrentPoint(postureData.imuData.longitude, postureData.imuData.latitude, postureData.imuData.yaw, 
				            rawRoadPoints, decisionData);
			
			//current point publisher
			currentPointPublisher(currentPoint_pub, decisionData);
			
			//calculate target steering angle and target steering velocity
			getSteeringAngle(postureData.imuData.longitude, postureData.imuData.latitude, postureData.imuData.yaw, 
				             postureData.imuData.velocity,  decisionData);

			// static std::ofstream fsDebug(debug_path, std::ofstream::trunc);
			// fsDebug << std::setprecision(12) << decisionData.bottom_enable_switch << " " << decisionData.bottom_driving_state << " " << postureData.imuData.longitude << " " << postureData.imuData.latitude << " " << postureData.imuData.yaw << " " << decisionData.currentPoint.longitude << " " << decisionData.currentPoint.latitude << " " << decisionData.currentPoint.courseAngle << " " << decisionData.targetSteeringAngle << " " << global_feedback_steering_angle << std::endl;


			ROS_INFO("[Z.H]now decisionData.currentState:%d", decisionData.currentState);
			if(decisionData.currentState == 1)
			{
				decisionData.targetWorkMode = 1;//following gps
				ROS_INFO("[Z.H]now following roadmap and run normal ~");
			}
			else{
				decisionData.targetWorkMode = 0;
				ROS_WARN("[Z.H]now not following roadmap and need to reset!");
			}
		}
		else{
			ROS_ERROR("[Z.H]NO IMU data, please check!!! IMU died???");
			decisionData.targetWorkMode = 0;
		}

		/*----------------LONGITUDINAL CONTROL------------------*/
		mapJudge(decisionData);
		if(lidarData.b_isValid == true && decisionData.targetWorkMode >= 1)
		{
			calculateLongitudinalControlParams(decisionData, postureData, lidarData, obstacleCell_pub);
			getTargetSpeed(decisionData);
			decisionData.targetWorkMode = 2;	
		}
		else
		{
			ROS_ERROR("[Z.H]NO LIDAR GRIDMAP or IMU data, please check!!! LIDAR died or IMU died???");
		}

		//decision pub
		std_msgs::Float64MultiArray decision_pub_array;
		decision_pub_array.data.clear();
		decision_pub_array.data.push_back(decisionData.targetWorkMode); //0: no GPS 1: followRoadmap(currentpoint was found in roadmap) and followGPS/GPS is good  2: GPS is good and Lidar is good
		decision_pub_array.data.push_back(decisionData.targetSpeed);
    	decision_pub_array.data.push_back(decisionData.targetSteeringAngle); // degree [-540,540]
    	decision_pub_array.data.push_back(decisionData.targetSteeringVelocity); // degree/s
		decision_pub_array.data.push_back(decisionData.full_stop_flag);// 0 or 1 
		decision_pub_array.data.push_back(decisionData.gear_cmd);// 1 N 2 D 3 R

		ROS_INFO_STREAM("[Z.H]PLANNING CONTROL FINAL PUB INFO:\n" << 
			          " 0.targetWorkMode: " << decision_pub_array.data[0] << "\n"
			          " 1.gear_cmd: " << decision_pub_array.data[5] << "\n"
			          " 2.targetSpeed: " << decision_pub_array.data[1]*3.6 << " km/h\n"
			          " 3.targetSteeringAngle: " << decision_pub_array.data[2] << " degree\n"
			          " 4.targetSteeringVelocity: " << decision_pub_array.data[3] << " degree/s\n"
			          " 5.full_stop_flag: " << decision_pub_array.data[4] << "\n\n");
		
    	decision_pub.publish(decision_pub_array);

		loop_rate.sleep();
	}

	return 0;
}

