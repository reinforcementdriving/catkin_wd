 /**
 * @file: planning_control.cpp
 * @author: Z.H
 * @date: 2019.08.08
 */
#include "planning_control/planning_control.hpp"

//global varibles assignment
int global_roadpoint_size = 0;
int global_stoppoint_size = 0;
double global_feedback_steering_angle = 0.0;
unsigned int global_feedback_gear = 0;

//record past path
bool global_path_record_switch = false;
bool global_path_record_time = 0;

DecisionData decisionData;
PostureData postureData;
LidarData lidarData;
std::vector<double> v_steering_angle_feedback;

//offset
double global_offset_temp_x = INFI;
double global_offset_temp_y = INFI;

/***********debug params***************/
double global_weight_yawdiff = 0.1;
double global_weight_steeringangle = 0.2;
double global_weight_odomheading = 0.5;


double PREVIEW_SAFE_WIDTH = 0;
double PREVIEW_SAFE_LENGTH = 0;
double TTC_REDUCE_SPEED_TIME = 0;
double SAFE_DISTANCE_MIN = 0;
double ACC_FOLLOW = 0;
/***********debug params***************/




//all function
bool inArea(const int id, const double X, const double Y, const double H,
	        const int id_, const double X_, const double Y_, const double H_, const double distance)
{
	bool ret = false;

	if ((id == id_) && (std::abs(X - X_) < distance) && (std::abs(Y - Y_) < distance) && (std::abs(H - H_) < distance)){
		ret = true;
	}
	else{
		ret = false;
	}

	return ret;
}


void loadRoadPoints(const std::string fileName, std::vector<RoadPoint> &rawRoadPoints)
{
	std::string line;
	std::ifstream fs;

	fs.open(fileName, std::ios::in);
	if (fs.fail()){
		ROS_ERROR("[Z.H]LOAD ROAD POINT FAIL!!!!!!");
	}
	int index = 0;
	while(getline(fs, line))
	{
		if (line.length() > 0){
			RoadPoint roadPoint;
			std::stringstream ss(line);
			
			ss >> roadPoint.road_id >> roadPoint.longitude >> roadPoint.latitude >> roadPoint.courseAngle >> roadPoint.parameter1 >> roadPoint.parameter2 >> roadPoint.parameter3;
			//roadPoint.courseAngle -= 4.6;
			if(roadPoint.courseAngle < 0)
				roadPoint.courseAngle += 360;
			roadPoint.index = index;
			rawRoadPoints.push_back(roadPoint);

			index++;
			
			// finding the minimum longitude and latitude
			if(global_offset_temp_x > roadPoint.longitude)
	        	global_offset_temp_x = roadPoint.longitude;
		    if(global_offset_temp_y > roadPoint.latitude)
		        global_offset_temp_y = roadPoint.latitude;
		}
	}
	
	global_roadpoint_size = rawRoadPoints.size();
	ROS_INFO("[Z.H]roadpoint max index is:%d", index);
	fs.close();
}

void loadStopPoints(const std::string fileName, std::vector<RoadPoint> &rawStopPoints)
{
	  
	std::string line;
    std::ifstream fs;

  	fs.open(fileName, std::ios::in);
	if (fs.fail()){
		ROS_ERROR("[Z.H]LOAD STOP POINT FAIL!!!!!!");
	
	}
	int index = 0;
	while(getline(fs, line))
	{
		if (line.length() > 0){
			RoadPoint roadPoint;
		  	std::stringstream ss(line);

		  	ss >> roadPoint.road_id >> roadPoint.longitude >> roadPoint.latitude >> roadPoint.courseAngle >> roadPoint.parameter1 >> roadPoint.parameter2 >> roadPoint.parameter3;
		  	
		  	roadPoint.index = index;
		  	rawStopPoints.push_back(roadPoint);

		  	index++;
		}
	}

	global_stoppoint_size = rawStopPoints.size();
	ROS_INFO("[Z.H]stoppoint max index is:%d", index);
	fs.close();
}



void buildFinalRoadPoints(std::vector<RoadPoint> &roadPoints, 
			        const std::vector<RoadPoint> &stopPoints)
{
	for(size_t i = 0; i < roadPoints.size(); ++i)
	{
		for(size_t k = 0; k < stopPoints.size();)
		{
			bool checkFlag = inArea(roadPoints[i].road_id, roadPoints[i].longitude, roadPoints[i].latitude, roadPoints[i].courseAngle, stopPoints[k].road_id, stopPoints[k].longitude, stopPoints[k].latitude, stopPoints[k].courseAngle, 0.05);
			if(true == checkFlag) {
		        if(stopPoints[k].parameter1 == 2) {
	            	roadPoints[i].parameter3 = std::fmin(roadPoints[i].parameter3, stopPoints[k].parameter3);
		            roadPoints[i].parameter1 = 2; //station stop
		        }
          		else if(stopPoints[k].parameter1 == 3){
            		roadPoints[i].parameter1 = 3;//takeover enable
          		}
          		else if(stopPoints[k].parameter1 == 4) {
	            	roadPoints[i].parameter3 = 16.7;//60km/h to m/s
		            roadPoints[i].parameter1 = 4; //the section road can be driving at 60km/h;
		        }
		        else;
		        break;
        	}
	        else{
	        	++k;
	        }
		}
	}  
}

void decisionSubCallback(const std_msgs::Float64MultiArray::ConstPtr &msg, DecisionData *decisionDataPtr)
{
	/**********************low pass filter steering angle feedback**********************/
	static double angle_old = 0;
	double angle_temp = msg->data[0];
  	decisionDataPtr->current_steering_angle = 0.95 * angle_old + 0.05 * angle_temp;
  	angle_old = decisionDataPtr->current_steering_angle;
  	global_feedback_steering_angle = decisionDataPtr->current_steering_angle;

  	/**********************mean filter steering angle feedback**********************/
  	/*
  	v_steering_angle_feedback.push_back(msg->data[0]);
  	if(v_steering_angle_feedback.size() < 10 && v_steering_angle_feedback.size() >= 0)
  	{
	  	decisionDataPtr->current_steering_angle = msg->data[0];
	  	global_feedback_steering_angle = decisionDataPtr->current_steering_angle;
  	}
  	else
  	{
  		double sum = std::accumulate(v_steering_angle_feedback.begin(), v_steering_angle_feedback.end(), 0.0);
  		decisionDataPtr->current_steering_angle = sum/v_steering_angle_feedback.size();
	  	global_feedback_steering_angle = decisionDataPtr->current_steering_angle;
	  	v_steering_angle_feedback.erase(v_steering_angle_feedback.begin());
  	}
  	*/

  	decisionDataPtr->bottom_driving_state = msg->data[1];
  	decisionDataPtr->bottom_enable_switch = msg->data[2];
  	decisionDataPtr->current_driving_mode = msg->data[3];
  	
  	ROS_INFO("[Z.H]received current_steering_angle: %.2f degree, bottom_driving_state: %d, bottom_enable_switch: %d", decisionDataPtr->current_steering_angle, decisionDataPtr->bottom_driving_state, decisionDataPtr->bottom_enable_switch);
}

void odomCallback(const nav_msgs::Odometry::ConstPtr &odom, PostureData *postureDataPtr, ros::Time *odomReceivedTimePtr)
{
	postureDataPtr->b_isValid = true;
	postureDataPtr->imuData.longitude = odom->pose.pose.position.x;
	postureDataPtr->imuData.latitude = odom->pose.pose.position.y;
	global_feedback_gear = (unsigned int)odom->twist.twist.linear.y;
	//converting rear axle speed to front axle speed
	if((std::abs(global_feedback_steering_angle/WHEEL_TO_TIRE) > 5) && odom->twist.twist.linear.x >= 0.2){
		postureDataPtr->imuData.velocity = odom->twist.twist.linear.x/std::cos(global_feedback_steering_angle/WHEEL_TO_TIRE*M_PI/180);//convert to front axle speed	
	}
	else if(odom->twist.twist.linear.x < 0.2){
		postureDataPtr->imuData.velocity = 0;
	}
	else{
		postureDataPtr->imuData.velocity = odom->twist.twist.linear.x;
	}
	
	/*************************normal get yaw *************************/
	/*
	postureDataPtr->imuData.yaw = tf::getYaw(odom->pose.pose.orientation)*180/M_PI;
	if(postureDataPtr->imuData.yaw < 0){
	    while(postureDataPtr->imuData.yaw < 0){
	        postureDataPtr->imuData.yaw += 360;
	    }
	}
	if(postureDataPtr->imuData.yaw > 360){
  		while(postureDataPtr->imuData.yaw > 360){
        	postureDataPtr->imuData.yaw -= 360;
	    }
	} 
	*/

	/**********************low pass filter yaw **********************/
	/*
	double yaw_temp = tf::getYaw(odom->pose.pose.orientation)*180/M_PI;//unit:du
	if(yaw_temp < 0) {
	  	while(yaw_temp < 0){
	    	yaw_temp += 360;
	  	}
	}
	else if(yaw_temp > 360){
	  	while(yaw_temp > 360){
	    	yaw_temp -= 360;
  		}
	}
	else;

	static double lastyaw = 0;
	double temp_out = 0;
	if(std::fabs(yaw_temp - lastyaw) > 180)
	{
		double temp_max = std::max(yaw_temp, lastyaw);

		if(temp_max == yaw_temp)
		{
			yaw_temp = yaw_temp - 360;

		}
		else
		{
			lastyaw = lastyaw - 360;
		}
	}

	temp_out = global_weight_odomheading * lastyaw + (1 - global_weight_odomheading) * yaw_temp;
	if(temp_out < 0)
		temp_out = temp_out + 360;	

	postureDataPtr->imuData.yaw = temp_out;//du 0~360
  	lastyaw = postureDataPtr->imuData.yaw;
	*/

    /*************************kf filter yaw *************************/
    
	double yaw_temp = tf::getYaw(odom->pose.pose.orientation)*180/M_PI;//unit:du
	if(yaw_temp < 0) {
	  	while(yaw_temp < 0){
	    	yaw_temp += 360;
	  	}
	}
	else if(yaw_temp > 360){
	  	while(yaw_temp > 360){
	    	yaw_temp -= 360;
  		}
	}
	else;

	static double lastyaw = 0;
	double temp_out = 0;
	if(std::fabs(yaw_temp - lastyaw) > 180)
	{
		double temp_max = std::max(yaw_temp, lastyaw);

		if(temp_max == yaw_temp)
		{
			yaw_temp = yaw_temp - 360;

		}
		else
		{
			lastyaw = lastyaw - 360;
		}
	}

	temp_out = global_weight_odomheading * (lastyaw + (((std::abs(postureDataPtr->imuData.velocity))*(std::tan(global_feedback_steering_angle/WHEEL_TO_TIRE*M_PI/180))*0.05/WHEELBASE)*180/M_PI)) + (1 - global_weight_odomheading) * yaw_temp;
	if(temp_out < 0)
		temp_out = temp_out + 360;	

	postureDataPtr->imuData.yaw = temp_out;//du 0~360
  	lastyaw = postureDataPtr->imuData.yaw;
  	

	int gps_state;
	gps_state = odom->pose.pose.position.z; 

	if(gps_state == 0x05 || gps_state == 0x0B)
	{
		postureDataPtr->imuData.b_isValid = true;					
		//path record
		if(global_path_record_switch == true)
		{
			if(global_path_record_time == 0)
			{
				postureDataPtr->longitude_array.clear();
				postureDataPtr->latitude_array.clear();
				postureDataPtr->yaw_array.clear();
				global_path_record_time = 1;
			}
		  	postureDataPtr->longitude_array.insert(postureDataPtr->longitude_array.begin(), odom->pose.pose.position.x);
		  	postureDataPtr->latitude_array.insert(postureDataPtr->latitude_array.begin(), odom->pose.pose.position.y);
		  	postureDataPtr->yaw_array.insert(postureDataPtr->yaw_array.begin(), postureDataPtr->imuData.yaw);
		  	if(postureDataPtr->longitude_array.size() > PAST_PATH_SIZE)
		  	{
			    postureDataPtr->longitude_array.pop_back();
			    postureDataPtr->latitude_array.pop_back();
			    postureDataPtr->yaw_array.pop_back();
		  	}
		}
		else
		{
			global_path_record_time = 0;
		}
	}
	else
	{
		postureDataPtr->imuData.b_isValid = false;
	}

	*odomReceivedTimePtr = ros::Time::now();
	ROS_INFO_STREAM("[Z.H]PLANNING CONTROL RECEIVE CURRENT ODOM INFO:\n" 
                      << " 1.gps_state: " << gps_state << "\n"
                      << " 2.current car speed: " << postureDataPtr->imuData.velocity * 3.6 << " km/h\n" 
                      << " 3.longitude: " <<  postureDataPtr->imuData.longitude << " latitude: " << postureDataPtr->imuData.latitude << "; yaw:" << postureDataPtr->imuData.yaw <<" degree\n"
                      << " 4.global_feedback_gear: " << global_feedback_gear << " \n");
}

void gridCallback(const nav_msgs::OccupancyGrid::ConstPtr &grid, LidarData *lidarDataPtr, ros::Time *lidarReceivedTimePtr)
{  
    int grid_width = (int)grid->info.width;
    int grid_height = (int)grid->info.height;
    int grid_size = (int)(grid_width * grid_height);
    double grid_resolution = grid->info.resolution;
    double x_minimum = grid->info.origin.position.x;
    double y_minimum = grid->info.origin.position.y;
    ROS_INFO("[Z.H]received a %d X %d map @ %.3f m/pix, Origin position x: %.3f, y: %.3f ",
              grid_width, grid_height, grid_resolution, x_minimum, y_minimum);

    lidarDataPtr->blockedAreaIndex.clear();
    lidarDataPtr->obstacle_coordinates.clear();
    
    //ROS_INFO("[Z.H]grid size: %d",grid_size);
    if(grid_size > 0){
	    for(size_t i = 0; i < grid_size; ++i)
	    {
	        if(grid->data[i] == 100)
	        {
	            lidarDataPtr->blockedAreaIndex.push_back(i);
	            size_t j = i%grid_width;
	            size_t k = i/grid_width;
	            Point p_coordinate;
	            p_coordinate.x = j * grid_resolution + x_minimum;
	            p_coordinate.y = k * grid_resolution + y_minimum;
	            lidarDataPtr->obstacle_coordinates.push_back(p_coordinate);
	        }
	        else
	            continue;
	    }
    }
    ROS_INFO("[Z.H]blockedAreaIndex size: %ld; obstacle_coordinates size: %ld",
             lidarDataPtr->blockedAreaIndex.size(), lidarDataPtr->obstacle_coordinates.size());
    
	lidarDataPtr->b_isValid = true;
    *lidarReceivedTimePtr = ros::Time::now();
}

void leftGridCallback(const nav_msgs::OccupancyGrid::ConstPtr &grid, LidarData *lidarDataPtr)
{  
    int grid_width = (int)grid->info.width;
    int grid_height = (int)grid->info.height;
    int grid_size = (int)(grid_width * grid_height);
    double grid_resolution = grid->info.resolution;
    double x_minimum = grid->info.origin.position.x;
    double y_minimum = grid->info.origin.position.y;
    // ROS_INFO("[Z.H]received [LEFT] a %d X %d map @ %.3f m/pix, Origin position x: %.3f, y: %.3f ",
    //           grid_width, grid_height, grid_resolution, x_minimum, y_minimum);

    lidarDataPtr->leftBlockedAreaIndex.clear();
    lidarDataPtr->left_obstacle_coordinates.clear();
    
    if(grid_size > 0){
      for(size_t i = 0; i < grid_size; ++i)
      {
        if(grid->data[i] == 100)
        {
            lidarDataPtr->leftBlockedAreaIndex.push_back(i);
            size_t j = i%grid_width;
            size_t k = i/grid_width;
            Point p_coordinate;
            p_coordinate.x = j * grid_resolution + x_minimum;
            p_coordinate.y = k * grid_resolution + y_minimum;
            lidarDataPtr->left_obstacle_coordinates.push_back(p_coordinate);
        }
        else
            continue;
      }
    }
    ROS_INFO("[Z.H][LEFT]blockedAreaIndex size: %ld; obstacle_coordinates size: %ld",
             lidarDataPtr->leftBlockedAreaIndex.size(), lidarDataPtr->left_obstacle_coordinates.size());   
}

void rightGridCallback(const nav_msgs::OccupancyGrid::ConstPtr &grid, LidarData *lidarDataPtr)
{  
    int grid_width = (int)grid->info.width;
    int grid_height = (int)grid->info.height;
    int grid_size = (int)(grid_width * grid_height);
    double grid_resolution = grid->info.resolution;
    double x_minimum = grid->info.origin.position.x;
    double y_minimum = grid->info.origin.position.y;
    // ROS_INFO("[Z.H]received [RIGHT] a %d X %d map @ %.3f m/pix, Origin position x: %.3f, y: %.3f ",
    //           grid_width, grid_height, grid_resolution, x_minimum, y_minimum);

    lidarDataPtr->rightBlockedAreaIndex.clear();
    lidarDataPtr->right_obstacle_coordinates.clear();
    
    if(grid_size > 0){
      for(size_t i = 0; i < grid_size; ++i)
      {
        if(grid->data[i] == 100)
        {
            lidarDataPtr->rightBlockedAreaIndex.push_back(i);
            size_t j = i%grid_width;
            size_t k = i/grid_width;
            Point p_coordinate;
            p_coordinate.x = j * grid_resolution + x_minimum;
            p_coordinate.y = k * grid_resolution + y_minimum;
            lidarDataPtr->right_obstacle_coordinates.push_back(p_coordinate);
        }
        else
            continue;
      }
    }
    ROS_INFO("[Z.H][RIGHT]blockedAreaIndex size: %ld; obstacle_coordinates size: %ld",
             lidarDataPtr->rightBlockedAreaIndex.size(), lidarDataPtr->right_obstacle_coordinates.size());   
}

void roadPointPublisher(ros::Publisher roadPoint_pub, const std::vector<RoadPoint> &RoadPoints)
{
	geometry_msgs::PoseArray cloud_msg;

	cloud_msg.header.stamp = ros::Time::now();
	cloud_msg.header.frame_id = "base_link";
	int size = RoadPoints.size();
	cloud_msg.poses.resize(size);

	for(size_t i = 0; i < size; ++i)
	{
		tf::poseTFToMsg(tf::Pose(tf::createQuaternionFromYaw(-(RoadPoints[i].courseAngle-90)/180*M_PI),
                                   tf::Vector3(RoadPoints[i].longitude-global_offset_temp_x, 
                                   	           RoadPoints[i].latitude-global_offset_temp_y, 
                                   	           0)), cloud_msg.poses[i]);
	}

	roadPoint_pub.publish(cloud_msg);
	ROS_INFO("[Z.H]roadPoint publish done~");
}

void pastPathPublisher(ros::Publisher past_path_pub, const PostureData &postureData)
{  
	geometry_msgs::PoseArray cloud_msg;

	cloud_msg.header.stamp = ros::Time::now();
	cloud_msg.header.frame_id = "base_link";

	int size = postureData.longitude_array.size();
	cloud_msg.poses.resize(size);
	
	for(size_t j = 0; j < size; ++j)
	{
		tf::poseTFToMsg(tf::Pose(tf::createQuaternionFromYaw(-(postureData.yaw_array[j]-90)/180*M_PI),
		                       tf::Vector3(postureData.longitude_array[j]-global_offset_temp_x, 
		                       	           postureData.latitude_array[j]-global_offset_temp_y,
		                       	           0)), cloud_msg.poses[j]);
	}

	past_path_pub.publish(cloud_msg);
	ROS_INFO("[Z.H]past_path publish done~");
}

double pointDistance(const double x1, const double x2, const double y1, const double y2)
{
	double distance;
	double dX;
	double dY;

	dX = std::abs(x1 - x2);
	dY = std::abs(y1 - y2);
	distance = sqrt(dX * dX + dY * dY);

	return distance;
}

double getAngle (const double x0, const double y0, const double x1, const double y1)
{
	double deltaY = y1 - y0;
	double deltaX = x1 - x0;

	return std::atan2(deltaY, deltaX)*180/M_PI;
}

double getAnglebtwn(const double x1, const double y1, const double x2, const double y2, const double c_a)
{
	// <0 left >0 right
	double a1 = getAngle(x2,y2,x1,y1);
	a1 = 90-a1;
	if(a1<0) 
		a1+=360;
	//return c_a-a1;
	return fmod((360 + 180 + c_a - a1), 360) - 180;
}


void getCurrentPoint(const double longitude, const double latitude, const double yaw, 
					 const std::vector<RoadPoint> &roadPoints, DecisionData &decisionData) 
{
	ROS_INFO("[Z.H]now current pose: long: %.3f lati: %.3f yaw: %.3f .", longitude, latitude, yaw);
	int size = roadPoints.size();
	std::vector<RoadPoint> roadPointCandidates;
	RoadPoint ret;
	RoadPoint ret_takeOver;

	double minimalX = 100, minimalY = 100;
	for(size_t i = 0; i < size; ++i) 
	{
		minimalX = std::abs(roadPoints[i].longitude - longitude) < minimalX ? std::abs(roadPoints[i].longitude - longitude) : minimalX;
      	minimalY = std::abs(roadPoints[i].latitude - latitude) < minimalY ? std::abs(roadPoints[i].latitude - latitude) : minimalY;

      	if ((std::abs(roadPoints[i].latitude - latitude) < 15) && 
     	    (std::abs(roadPoints[i].longitude - longitude) < 15) 
     	    //&& (std::fabs((360 + 180 + (int)roadPoints[i].courseAngle - (int)yaw)%360 - 180) < 90)
     	    )
      	{
      		roadPointCandidates.push_back(roadPoints[i]);
      	}
      	else;
	}

	int candidateSize = roadPointCandidates.size();
	
	if(candidateSize < 1){
		ROS_ERROR("[Z.H]NO current point!!!");
		ROS_WARN("[Z.H]current pose the nearest point in map is: Min X: %f ; Min Y: %f.", minimalX, minimalY);
		ret.b_isValid = false;
		ret_takeOver.b_isValid = false;		
  	}

  	if(candidateSize > 0)
  	{	
  		int index_temp = 0;
		double dist = INFI;
		for(size_t j = 0; j < candidateSize; ++j)
		{
			double dist_temp = pointDistance(longitude, roadPointCandidates[j].longitude, latitude, roadPointCandidates[j].latitude);
			if(dist_temp < dist)
			{
				dist = dist_temp;
				index_temp = j;
			}
		}
		ret = roadPointCandidates[index_temp];
		ret.b_isValid = true;

		//get lateral distance
		double disError = ((longitude - ret.longitude) * std::cos(ret.courseAngle*M_PI/180)) - ((latitude - ret.latitude) * std::sin(ret.courseAngle*M_PI/180));
		ret.lateral_dist = disError;
		ROS_INFO("[Z.H]now find currentpoint in map the nearest distance is %f m.", dist);
		ROS_INFO("[Z.H]the nearestPoint in map:\n long: %f lati: %f yaw: %f lateral_dist: %f.", ret.longitude, ret.latitude, ret.courseAngle, ret.lateral_dist);


		//get ret_takeOver
		ret_takeOver = ret;
		ret_takeOver.longitude = ret.longitude - std::cos(ret.courseAngle*M_PI/180) * 4;
  		ret_takeOver.latitude = ret.latitude + std::sin(ret.courseAngle*M_PI/180) * 4;
  		ret_takeOver.courseAngle = ret.courseAngle;
  		ret_takeOver.parameter3 = 6/3.6;
  		double disErrorTakeOver = ((longitude - ret_takeOver.longitude) * std::cos(ret_takeOver.courseAngle*M_PI/180)) - ((latitude - ret_takeOver.latitude) * std::sin(ret_takeOver.courseAngle*M_PI/180));
		ret_takeOver.lateral_dist = disErrorTakeOver;
		ROS_INFO("[Z.H]the nearestPoint takeOver in map:\n long: %f lati: %f yaw: %f lateral_dist: %f .", ret_takeOver.longitude, ret_takeOver.latitude, ret_takeOver.courseAngle, ret_takeOver.lateral_dist);
	}

	//assignment
  	decisionData.currentPoint = ret;
  	decisionData.currentPoint_takeOver = ret_takeOver;

  	/*
  	int temp_index = ret.index + 250;
  	if(temp_index < size && temp_index >= 0)
  	{
  		decisionData.currentPoint.parameter3 = roadPoints[temp_index].parameter3;
  	}
  	*/
}




/*
void getCurrentPoint(const double longitude, const double latitude, const double yaw, 
	                 const std::vector<RoadPoint> &roadPoints, DecisionData &decisionData)
{
	int size = roadPoints.size();
	RoadPoint ret;
	// the first search
	if(decisionData.currentpoint_id < 0 || decisionData.currentpoint_id >= size ||
	   decisionData.last_currentpoint_id < 0 || decisionData.last_currentpoint_id >= size) 
	{
		int index_temp = 0;
		double dist = INFI, dist_temp = 0;
		for(size_t i = 0; i < size; ++i)
		{
			dist_temp = pointDistance(longitude, roadPoints[i].longitude, latitude, roadPoints[i].latitude);
			if(dist_temp < dist)
			{
				dist = dist_temp;
				index_temp = i;
			}
		}
		
		decisionData.currentpoint_id = index_temp;
		decisionData.last_currentpoint_id = decisionData.currentpoint_id;
		ROS_INFO("[Z.H]first currentpoint id in roadmap is : %d",decisionData.currentpoint_id);
		ROS_INFO("[Z.H]first currentpoint find in roadmap distance to current pose is : %f", dist);

		//return
		ret = roadPoints[index_temp];
		ret.b_isValid = true;
		if(ret.index != index_temp){
			ROS_ERROR("[Z.H] please check get current point !!! index error???");
		}

		//use for stanley
		ROS_INFO_STREAM("[Z.H] now get the current point is: " 
			<< "long:" << ret.longitude << " lati:" << ret.latitude << " yaw:" << ret.courseAngle);
		double a_b = getAnglebtwn(longitude, latitude, ret.longitude, ret.latitude, ret.courseAngle);

	    if(a_b >= 0)
	      	ret.lateral_dist = dist;
	    else
	      	ret.lateral_dist = -dist;
	}

	// not the first search
	else 
	{
		int index_temp = 0;
		double dist = INFI, dist_temp = 0;
		int begin = decisionData.last_currentpoint_id;

		if(begin >= 200) {
			for(int j = begin-200; j < begin+200; ++j) {
				dist_temp = pointDistance(longitude, roadPoints[j].longitude, latitude, roadPoints[j].latitude);
				if(dist_temp < dist) {
					dist = dist_temp;
					index_temp = j;
				}
			}
		}
		else {
			for(int j = 0; j < begin+200; ++j) {
				dist_temp = pointDistance(longitude, roadPoints[j].longitude, latitude, roadPoints[j].latitude);
				if(dist_temp < dist) {
					dist = dist_temp;
					index_temp = j;
				}
			}
		}
		//judge
		if(dist < MIN_DISTANCE_TO_POSE)
		{
			decisionData.currentpoint_id = index_temp;
			decisionData.last_currentpoint_id = decisionData.currentpoint_id;
			ROS_INFO("[Z.H]currentpoint id in roadmap is : %d",decisionData.currentpoint_id);
			ROS_INFO("[Z.H]currentpoint find in roadmap distance to current pose is : %f", dist);

			//return
			ret = roadPoints[index_temp];
			ret.b_isValid = true;
			if(ret.index != index_temp){
				ROS_ERROR("[Z.H] please check get current point !!! index error???");
			}
		}
		else
		{
			ROS_WARN("[Z.H]currentpoint is not find in roadmap,and distance to current pose is : %f", dist);
			decisionData.currentpoint_id = begin;
			decisionData.last_currentpoint_id = decisionData.currentpoint_id;
			//return
			ret = roadPoints[begin];
			ret.b_isValid = false;
			if(ret.index != begin){
				ROS_ERROR("[Z.H] please check get current point !!! index error???");
			}
		}

		//use for stanley
		ROS_INFO_STREAM("[Z.H] now get the current point is: " 
			<< "long:" << ret.longitude << " lati:" << ret.latitude << " yaw:" << ret.courseAngle);
		double a_b = getAnglebtwn(longitude, latitude, ret.longitude, ret.latitude, ret.courseAngle);

	    if(a_b >= 0)
	      	ret.lateral_dist = dist;
	    else
	      	ret.lateral_dist = -dist;
	}
	//assignment
	decisionData.currentPoint = ret;
}
*/

void currentPointPublisher(ros::Publisher currentPoint_pub, const DecisionData &decisionData)
{
	geometry_msgs::PoseArray cloud_msg;

	cloud_msg.header.stamp = ros::Time::now();
	cloud_msg.header.frame_id = "base_link";

	RoadPoint currentPoint_temp = decisionData.currentPoint;
	if(currentPoint_temp.b_isValid == true)
	{
		cloud_msg.poses.resize(1);
  		tf::poseTFToMsg(tf::Pose(tf::createQuaternionFromYaw(-(currentPoint_temp.courseAngle-90)/180*M_PI),
                                   tf::Vector3(currentPoint_temp.longitude-global_offset_temp_x,
                                               currentPoint_temp.latitude-global_offset_temp_y, 
                                               0)), cloud_msg.poses[0]);

	}
	currentPoint_pub.publish(cloud_msg);
	ROS_INFO("[Z.H]currentPoint publish done~");
}

/**
 * @brief  getAngleDiff
 * @param  ang0: yaw  0 ~ 360;
 * @param  ang1: current angle:  -180 ~ 180
 */
double getAngleDiff (double ang0, double ang1)
{
	if (ang0 > 180) {
		ang0 = ang0 - 360;
	}

	ang0 = -ang0;
	ang1 = ang1 - 90;

	if (ang1 < -180) {
		ang1 = ang1 + 360;
	}
	
	double ret = ang1 - ang0;
	if (ret > 180) {
		ret = ret - 360;
	}
	else if (ret < -180){
		ret = ret + 360;
	}
	
	return ret;
}

/**
 * @brief  getYawDiff
 * @param  yawVehicle: 0 ~ 360;
 * @param  yawRoad: 0 ~ 360
 */
double getYawDiff (double yawVehicle, double yawRoad)
{
	if (yawVehicle > 180) {
		yawVehicle = yawVehicle - 360;
	}
	else;
	yawVehicle = -yawVehicle;

	if (yawRoad > 180) {
		yawRoad = yawRoad - 360;
	}
	else;
	yawRoad = -yawRoad;

	double ret = yawRoad - yawVehicle;

	if (ret > 180) {
		ret = ret - 360;
	}
	else if (ret < -180){
		ret = ret + 360;
	}
	else;

	return ret;
}

/*
 * KDStanley 4      
 * StanleyPDist 0.5    
 * StanleyYKD 2  
 * P_dist_stanley 1.5 
 */
double stanley(const RoadPoint &currentPoint, const double &yawDiff, const double &velocity)
{
	double ksoft = 1;
	std::cout << "[Z.H] stanley now yawdiff:" << yawDiff << std::endl;
	static double l_y = 0;

	double inner = KDStanley * currentPoint.lateral_dist / (ksoft + velocity);
	//double s_angle = yawDiff + StanleyYKD * (yawDiff - l_y)/0.1 + StanleyPDist * atan(inner);
	double s_angle = -(yawDiff + StanleyPDist * atan(inner));
	l_y = yawDiff;
	ROS_INFO_STREAM("[Z.H]STANLEY PARAMS INFO:\n" << 
			          " 1.current velocity: " << velocity*3.6 << "km/h\n"
			          " 2.currentPoint.lateral_dist: " << currentPoint.lateral_dist << "\n"
			          " 3.atan(xx): " << atan(inner) << "\n"
			          " 4.angle error: " << yawDiff << " rad\n"
			          //" 5.calculate angle error section: " << (yawDiff + StanleyYKD * (yawDiff - l_y)/0.1) << "\n"
			          " 6.stanley out: " << s_angle*180/M_PI << " degree");

	return s_angle*180/M_PI;
}


double getSteeringVelocity(const double &current_v)
{

	double res = 0;//degree/s 

	if(current_v * 3.6 <= 0.2)
		res = 0;
	else if(current_v * 3.6 > 0.2 && current_v * 3.6 < 5)
		res = (current_v * 3.6 - 0)*60;
	else if(current_v * 3.6 >= 5 && current_v * 3.6 < 20)
		res = 300;
	else if(current_v * 3.6 >= 20 && current_v * 3.6 < 60)
		res = 300 - (current_v * 3.6 - 20)*5;
	else if(current_v * 3.6 >= 60)
		res = 100;
	else;

	return res;
}

/***************************************OLD before 2019.10.26**************************************************/
/*
void getSteeringAngle(const double longitude, const double latitude, const double yaw, 
	                  const double velocity, DecisionData &decisionData)
{

	if(decisionData.currentPoint.b_isValid == true)
	{
		decisionData.currentState = 1;//follow roadmap

		double currentAngle = 0.0;
		if (false == decisionData.b_takingOver){
	        currentAngle = getAngle(longitude, latitude, decisionData.currentPoint.longitude, decisionData.currentPoint.latitude);
	        ROS_INFO("[Z.H]now following normal lane.");
      	}
      	else// during taking over
      	{
      		ROS_INFO("[Z.H]now is takingover and following left lane.");
      	}

      	///
      	 //@brief  yawdiff
      	 //@param  yawdiff: the yaw difference between the car yaw(yaw) and the nearest point yaw(yaw) in roadmap
      	 //
		static double last_yawDiff = 0;
		double yawDiff = getYawDiff(yaw, decisionData.currentPoint.courseAngle);
		ROS_INFO("[Z.H]now calculate 1.yaw: %f; 2.currentCourseAngle: %f; 3.yawDiff: %f", yaw, decisionData.currentPoint.courseAngle, yawDiff);
		yawDiff = global_weight_yawdiff * yawDiff  + (1 - global_weight_yawdiff) * last_yawDiff;
		last_yawDiff = yawDiff;
		ROS_INFO("[Z.H]final calculate send to stanley yawDiff: %f degree", yawDiff);
		
		// main stanley
		double error_a = yawDiff * M_PI/180;
		double vel_stanley;
		if(velocity < 1.5)
			vel_stanley = 1.5;
		else
			vel_stanley = velocity;
		double v_angle = stanley(decisionData.currentPoint, error_a, vel_stanley);
		
		//stablizer
		
		static double last_v_angle = 0;		
		v_angle = v_angle + 0.8 * (v_angle - last_v_angle);
		last_v_angle = v_angle;
		ROS_INFO("[Z.H]actual v_angle: %f.", v_angle);
		
		double s_angle = v_angle * WHEEL_TO_TIRE;
		if (s_angle > 530) 
	      	s_angle = 530;
	    if (s_angle < -530)
	      	s_angle = -530;
	    
	    static double last_s_angle = 0;
		s_angle = global_weight_steeringangle * s_angle + (1 - global_weight_steeringangle) * last_s_angle;
		last_s_angle = s_angle;
		

		ROS_INFO("[Z.H][getSteeringAngle]calculate target steering angle is:%f degree", s_angle);
		decisionData.targetSteeringAngle = s_angle ;
		
		double temp_steering_velocity = getSteeringVelocity(velocity);//degree/s
		decisionData.targetSteeringVelocity = temp_steering_velocity;
		ROS_INFO("[Z.H][getSteeringAngle]calculate target steering velocity is:%f degree/s", decisionData.targetSteeringVelocity);

        ///
         //@brief set the default target speed
         //
        decisionData.targetSpeed = decisionData.currentPoint.parameter3;;
        ROS_INFO("[Z.H][getSteeringAngle]set the default targetspeed is:%f km/h", decisionData.targetSpeed*3.6);
		
		//debug
		//std::string path = "/home/a/Desktop/debug.txt";
		//static std::ofstream fsDebug(path, std::ofstream::trunc);
		//fsDebug << decisionData.currentPoint.index << " " << longitude << " " << latitude << " " << yaw << " " << decisionData.currentPoint.lateral_dist << " " << yawDiff << std::endl;
		
	}
	else
	{
		decisionData.currentState = 0;
	}
}
*/

/***************************************NEW after 2019.10.26**************************************************/

void getSteeringAngle(const double longitude, const double latitude, const double yaw, 
	                  const double velocity, DecisionData &decisionData)
{
	double tire_angle_feedback = global_feedback_steering_angle/WHEEL_TO_TIRE;

	if(decisionData.currentPoint.b_isValid == true)
	{
		decisionData.currentState = 1;//follow roadmap

		if (false == decisionData.b_takingOver){
	        ROS_INFO("[Z.H]now following normal lane.");
      	}
      	else// during taking over
      	{
      		ROS_INFO("[Z.H]now is takingover and following left lane.");
      	}

      	///
      	 // @brief  calculate targetSteeringAngle
      	 // @param  anglError: the yaw difference between the car yaw(yaw) and the nearest point yaw(yaw) in roadmap
      	 // @param  distError: the lateral distance of  the current pose and the the nearest point in roadmap
      	static double oldCmd = 0;
      	static double oldAnglError = 0;
      	static double oldDist2Angle = 0;

      	double anglError = getYawDiff(yaw, decisionData.currentPoint.courseAngle);// unit degree
      	double distError = decisionData.currentPoint.lateral_dist;

      	double anglErrorTemp = anglError * LKA_Akp  + (anglError - oldAnglError) * LKA_Akd;

      	double dist2Angle = atan((4 * distError)/(1 + std::abs(velocity)))*180/M_PI;// unit degree
      	double distErrorTemp = dist2Angle * LKA_Dkp + (dist2Angle - oldDist2Angle) * LKA_Dkd;

      	double angCmdTemp = -(anglErrorTemp + distErrorTemp);
      	double angCmd = (angCmdTemp - (global_feedback_steering_angle/WHEEL_TO_TIRE)) * LKA_Dyn + angCmdTemp;//tire angle cmd output 
      	
      	if(angCmd > thetaMax)
      		angCmd = thetaMax;
		if(angCmd < -thetaMax)	
			angCmd = -thetaMax;

		oldAnglError = anglError;
		oldDist2Angle = dist2Angle;
		ROS_INFO_STREAM("[Z.H][getSteeringAngle][SteeringAngle Params]:\n" <<
		 			  " 0.tire_angle_feedback:" << tire_angle_feedback << " degree\n"
			          " 1.anglError: " << anglError << " degree\n"
			          " 2.distError: " << distError << " m\n"
			          " 3.anglErrorTemp: " << anglErrorTemp << " degree\n"
			          " 4.dist2Angle: " << dist2Angle << " degree\n"
			          " 5.distErrorTemp: " << distErrorTemp << " degree\n"
			          " 6.angCmdTemp: " << angCmdTemp << " degree\n"
			          " 7.angCmd: " << angCmd << " degree\n");
		
		//SteeringRateRegulation
		double angFBTemp = std::abs(tire_angle_feedback)/thetaMax * (2.0/3.0) + (1.0/3.0);
		double angFBTemp1 = 0;

		if(std::abs(velocity) < 0.1)//unit m/s
			angFBTemp1 = std::abs(velocity);
		else if(std::abs(velocity) >= 0.1 && std::abs(velocity) < 4)
			angFBTemp1 = 1;
		else if(std::abs(velocity) >= 4)
			angFBTemp1 = 1- 0.2 * (std::abs(velocity) - 4);
		else;

		double strSpd = angFBTemp * angFBTemp1;
		if(strSpd > 1)
			strSpd = 1;
		if(strSpd < 0) 
			strSpd = 0;
		strSpd = strSpd * 0.5;
		ROS_INFO_STREAM("[Z.H][getSteeringAngle][SteeringRate Regulation]:\n" << 
			          " 1.angFBTemp: " << angFBTemp << " degree\n"
			          " 2.angFBTemp1: " << angFBTemp1 << " degree\n"
			          " 3.strSpd: " << strSpd << " \n"
			          " 4.now tire oldCmd: " << oldCmd << " degree\n");

		//SteeringAngle Stablizer
		double strAngTemp = angCmd * (std::abs(angCmd)/thetaMax * (2.0/3.0) + (1.0/3.0));
		double strAngDiff = std::abs(strAngTemp - oldCmd);
		double strAngNew = 0;
		double strCmd = 0;

		if(strAngDiff <= strSpd)
			strAngNew = 0;
		else
			strAngNew = (strAngTemp - oldCmd)/strAngDiff * strSpd;

		strCmd = strAngNew + oldCmd;
		if(strCmd > thetaMax)
      		strCmd = thetaMax;
		if(strCmd < -thetaMax)	
			strCmd = -thetaMax;

		oldCmd = strCmd;
		double s_angle = strCmd * WHEEL_TO_TIRE;

		decisionData.targetSteeringAngle = s_angle ;
		if(decisionData.full_stop_flag)
			decisionData.targetSteeringVelocity = 0;
		else
			decisionData.targetSteeringVelocity = 300;
		ROS_INFO_STREAM("[Z.H][getSteeringAngle][SteeringAngle Stablizer]:\n" << 
			          " 1.strAngTemp: " << strAngTemp << " degree\n"
			          " 2.strAngDiff: " << strAngDiff << " degree\n"
			          " 3.strAngNew: " << strAngNew << " degree\n"
			          " 4.tire strCmd: " << strCmd << " degree\n"
			          " 5.wheel target steering angle: " << decisionData.targetSteeringAngle << " degree\n"
			          " 6.wheel target steering velocity: " << decisionData.targetSteeringVelocity << " degree/s\n");
        ///
         //@brief set the default target speed
         //
        decisionData.targetSpeed = decisionData.currentPoint.parameter3;;
        ROS_INFO("[Z.H][getSteeringAngle]set the default targetspeed is:%f km/h", decisionData.targetSpeed*3.6);
		
		//debug
		std::string pa = "/home/a/Desktop/debug1.txt";
		static std::ofstream fs(pa, std::ofstream::trunc);
		fs << decisionData.currentPoint.index << " " << longitude << " " << latitude << " " << yaw << " " << decisionData.currentPoint.courseAngle << " " << distError << " " << anglError << " " << decisionData.targetSteeringAngle << " " << global_feedback_steering_angle << std::endl;

	}
	else
	{
		decisionData.currentState = 0;
	}
}



void mapJudge(DecisionData &decisionData)
{
	decisionData.b_takeOverEnable = false;
	decisionData.b_redLightStopped = false;
	decisionData.stationStopFlag = false; //station stop

	decisionData.targetSpeed = std::fmin(decisionData.targetSpeed, decisionData.currentPoint.parameter3);

	if (decisionData.currentPoint.parameter1 == 1){//traffic light 
		ROS_WARN("[Z.H]this is traffic light point!!!");
	}
	else if(decisionData.currentPoint.parameter1 == 2){//station stop
		ROS_WARN("[Z.H]this is station stop point!!!");
		decisionData.stationStopFlag = true; 
	}
	else if(decisionData.currentPoint.parameter1 == 3){//overtake enable
		ROS_WARN("[Z.H]this is overtaking enabled point!!!");
		decisionData.b_takeOverEnable = true;
	}
	else;
}


void calculateLongitudinalControlParams(DecisionData &decisionData, const PostureData &postureData, 
	                                    const LidarData &lidarData, ros::Publisher obstacleCell_pub)
{
	//pub obstacle grid in the observation area
	nav_msgs::GridCells cell_msg;
    cell_msg.header.frame_id = "base_link";
    cell_msg.header.stamp = ros::Time::now();
    cell_msg.cell_height = 0.25;
  	cell_msg.cell_width = 0.25;
  	cell_msg.cells.clear();
  	geometry_msgs::Point cell_p;

	double current_v_front = postureData.imuData.velocity;// front axle speed / linear velocity
	double tire_angle_feedback = global_feedback_steering_angle/WHEEL_TO_TIRE;
	double tire_angle_feedback_rad = tire_angle_feedback*M_PI/180;

	double v_temp = current_v_front * 3.6;//km/h
	PREVIEW_SAFE_WIDTH = 0.0110 * v_temp + 0.3936;
	//PREVIEW_SAFE_LENGTH = -0.0083 * v_temp * v_temp + 0.98 * v_temp + 12.5;
	PREVIEW_SAFE_LENGTH = 50;
	TTC_REDUCE_SPEED_TIME = 8;

	//calculate ttc and dtc
	if(std::fabs(tire_angle_feedback) > 5 && std::abs(decisionData.currentPoint.parameter2) >= 0.01)
	{
		ACC_FOLLOW = 2;
		double r_front = WHEELBASE/std::sin(tire_angle_feedback_rad);
		double r_back = r_front*(std::cos(tire_angle_feedback_rad));

		ROS_INFO("[Z.H]calculate 1.r_front: %f m  2.r_back: %f m.", r_front, r_back);
		Point circle_point;//center of circle
		circle_point.x = r_back;
		circle_point.y = -WHEELBASE;
	
		double angular_speed = current_v_front/(std::fabs(r_front));//rad/s
		// double angular_speed_map = judgeSpeed/(std::fabs(r_front));//rad/s
		// ROS_INFO("[Z.H]current angular_speed:%f rad/s; angular_speed_map: %f rad/s.", angular_speed, angular_speed_map);
		double r_min = (std::fabs(r_back)) - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double r_max = (std::fabs(r_front)) + CAR_WIDTH + PREVIEW_SAFE_WIDTH;

		std::vector<double> v_ttc;//time to collision
		std::vector<double> v_dtc;//distance to collision
		if(!lidarData.obstacle_coordinates.empty())
		{
		    int len = lidarData.obstacle_coordinates.size();
		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        double r_temp = sqrt((p_x - circle_point.x)*(p_x - circle_point.x) + (p_y - circle_point.y)*(p_y - circle_point.y));
		        
		        if(r_temp <= r_max && r_temp >= r_min){
		        	cell_p.x = p_x;
		        	cell_p.y = p_y;
		        	cell_p.z = 0;
		        	cell_msg.cells.push_back(cell_p);

		            double alpha = std::atan2(p_y + WHEELBASE, std::fabs(r_back - p_x));//rad
		            if(alpha > std::fabs(tire_angle_feedback_rad)){
		                double ttc = (alpha - std::fabs(tire_angle_feedback_rad))/(angular_speed + 0.0001);
		                double dtc = (alpha - std::fabs(tire_angle_feedback_rad)) * (std::fabs(r_front));//arc length
		                v_ttc.push_back(ttc);
		                v_dtc.push_back(dtc);
		            }   
		        }
		    }

		    if(v_ttc.size() > 0 && v_dtc.size() > 0)
		    {
		    	double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
		    	double dtc_min = *min_element(v_dtc.begin(), v_dtc.end());
		    	ROS_INFO("[Z.H]when tire_angle_feedback is useful,now ttc_min: %f s, dtc_min: %f m", ttc_min, dtc_min);

		    	decisionData.obstacle_isValid = true;
		    	decisionData.obstacle_dtc_min = dtc_min;
		    	decisionData.obstacle_ttc_min = ttc_min;
		    	decisionData.relative_speed = -current_v_front;//m/s
		    	decisionData.relative_speed_map = decisionData.currentPoint.parameter3;	
			}
			else
			{
				decisionData.obstacle_isValid = false;
		    	decisionData.obstacle_dtc_min = 1000;
		    	decisionData.obstacle_ttc_min = 1000;
		    	decisionData.relative_speed = -current_v_front;//m/s
		    	decisionData.relative_speed_map = decisionData.currentPoint.parameter3;
			}    
		}
		else
		{
			decisionData.obstacle_isValid = false;
	    	decisionData.obstacle_dtc_min = 1000;
	    	decisionData.obstacle_ttc_min = 1000;
	    	decisionData.relative_speed = -current_v_front;//m/s
	    	decisionData.relative_speed_map = decisionData.currentPoint.parameter3;	
		}
	}
	
	else//std::fabs(tire_angle_feedback) < 7
	{
		ACC_FOLLOW = 12;
		double min_x = 0.0 - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double max_x = 0.0 + CAR_WIDTH + PREVIEW_SAFE_WIDTH;
		double min_y = 0.1;
		double max_y = PREVIEW_SAFE_LENGTH;
		std::vector<double> v_ttc;//time to collision
		std::vector<double> v_dtc;//distance to collision
		
		if(!lidarData.obstacle_coordinates.empty()) 
		{
		    int len = lidarData.obstacle_coordinates.size();
		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        if(p_x <= max_x && p_x >= min_x && p_y <= max_y && p_y >= min_y){
		        	cell_p.x = p_x;
		        	cell_p.y = p_y;
		        	cell_p.z = 0;
		        	cell_msg.cells.push_back(cell_p);

		            double ttc = std::fabs(p_y)/(current_v_front + 0.0001);
		            //ROS_INFO("[Z.H]now in preview area obstacle to the bus distance is %f m. and the arrived time is %f s", std::fabs(p_y), ttc);
		            v_ttc.push_back(ttc);
		            v_dtc.push_back(std::fabs(p_y));
		        }
		    }

		    if(v_ttc.size() > 0 && v_dtc.size() > 0)
		    {
		    	double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
		    	double dtc_min = *min_element(v_dtc.begin(), v_dtc.end());
			    ROS_INFO("[Z.H]when tire_angle_feedback is too small and is invalid, now ttc_min: %f s; dtc_min: %f m", ttc_min, dtc_min);
			    
			    decisionData.obstacle_isValid = true;
		    	decisionData.obstacle_dtc_min = dtc_min;
		    	decisionData.obstacle_ttc_min = ttc_min;
		    	decisionData.relative_speed = -current_v_front;//m/s
		    	decisionData.relative_speed_map = decisionData.currentPoint.parameter3;
		    }
		    else
			{
				decisionData.obstacle_isValid = false;
		    	decisionData.obstacle_dtc_min = 1000;
		    	decisionData.obstacle_ttc_min = 1000;
		    	decisionData.relative_speed = -current_v_front;//m/s
		    	decisionData.relative_speed_map = decisionData.currentPoint.parameter3;
			} 

		}
		else
		{
			decisionData.obstacle_isValid = false;
	    	decisionData.obstacle_dtc_min = 1000;
	    	decisionData.obstacle_ttc_min = 1000;
	    	decisionData.relative_speed = -current_v_front;//m/s
	    	decisionData.relative_speed_map = decisionData.currentPoint.parameter3;	
		}
	}
	obstacleCell_pub.publish(cell_msg);
}

void getTargetSpeed(DecisionData &decisionData)
{
	ROS_INFO_STREAM("[Z.H][getTargetSpeed]:\n" << 
					  " 1.steering_angle_feedback: " << global_feedback_steering_angle << " degree\n"
					  " 2.tire_angle_feedback: " << global_feedback_steering_angle/WHEEL_TO_TIRE << " degree\n"
					  " 3.currentpoint index: " << decisionData.currentPoint.index << " \n"
					  " 4.currentpoint curvature: " << decisionData.currentPoint.parameter2 << " \n"
					  " 5.now PREVIEW_SAFE_WIDTH: " << PREVIEW_SAFE_WIDTH << " m\n"
					  " 6.now PREVIEW_SAFE_LENGTH: " << PREVIEW_SAFE_LENGTH << " m\n"
			          " 7.obstacle_isValid: " << decisionData.obstacle_isValid << "\n"
			          " 8.obstacle_dtc_min: " << decisionData.obstacle_dtc_min << " m\n"
			          " 9.obstacle_ttc_min: " << decisionData.obstacle_ttc_min << " s\n"
			          " 10.relative_speed: " << decisionData.relative_speed*3.6 << " km/s\n"
			          " 11.relative_speed_map: " << decisionData.relative_speed_map*3.6 << " km/s\n");
	double advisedSpeed = decisionData.targetSpeed;
	static bool oldFullStop = false;
	static double oldSpdCmdOutput = 0;

	static double oldRelSpd = 0;
	static double oldDistError = 0;

	double distError, expSpdDiff, expSpdDiffA, expSpdDiffB;
	//---------state selection of speed into a finite state machine--------//
    //state transition
    switch(Main_State)
	{
		case Normal_Cruise:
		{
			if(decisionData.obstacle_isValid == true)
				Main_State = Speed_Regulation;
			break;
		}
		case Speed_Regulation:
		{		
			if(decisionData.obstacle_isValid == false)
				Main_State = Normal_Cruise;
			else 
			{
				SAFE_DISTANCE_MIN = 4 - ACC_TTC * decisionData.relative_speed;	
				ROS_INFO("[Z.H][Speed_Regulation]:now SAFE_DISTANCE_MIN:%f m", SAFE_DISTANCE_MIN);
				if((decisionData.obstacle_dtc_min <= SAFE_DISTANCE_MIN || decisionData.velocity <= 0.1 || oldFullStop) && ((ACC_THW * decisionData.relative_speed_map * 0.5) > decisionData.obstacle_dtc_min))
					Main_State = Emergent_Brake;	
			}			
			break;
		}
		case Emergent_Brake:
		{
			if(decisionData.obstacle_isValid == false)//|| decisionData.obstacle_dtc_min > decisionData.relative_speed_map * 8
				Main_State = Normal_Cruise;
			else 
			{
				SAFE_DISTANCE_MIN = 4 - ACC_TTC * decisionData.relative_speed;	
				ROS_INFO("[Z.H][Emergent_Brake]:now SAFE_DISTANCE_MIN:%f m", SAFE_DISTANCE_MIN);
				if((decisionData.obstacle_dtc_min > SAFE_DISTANCE_MIN && decisionData.velocity >= 0 && (!oldFullStop)) || ((ACC_THW * decisionData.relative_speed_map * 0.5) <= decisionData.obstacle_dtc_min))
					Main_State = Speed_Regulation;
			}
			break;
		}

		default: break;
	}

	//state output
	switch(Main_State)
	{
		case Normal_Cruise:
		{
			
			if(std::abs(oldSpdCmdOutput) < decisionData.targetSpeed)
			{
				advisedSpeed = std::abs(oldSpdCmdOutput) + 0.04;
			}
			else
				advisedSpeed = decisionData.targetSpeed;//to be decisionData.relative_speed_map
			
			//advisedSpeed = decisionData.targetSpeed;//to be decisionData.relative_speed_map
			decisionData.full_stop_flag = 0;
			break;
		}
		case Speed_Regulation:
		{
			double spdExp, spdCmd, spdTemp;
			static double oldSpdExp = 0;//decisionData.relative_speed_map
			static double oldSpdCmd = 0;//decisionData.velocity

			distError = decisionData.obstacle_dtc_min - (std::abs(decisionData.velocity) * ACC_THW + 12);
			expSpdDiffB = (distError * ACC_DKp + (distError - oldDistError) * ACC_DKd) * 0.0025;// 20fps (1/20) * (1/20)
			expSpdDiffA = (decisionData.relative_speed * ACC_VKp + (decisionData.relative_speed - oldRelSpd) * ACC_VKd) * 0.05;
			expSpdDiff = expSpdDiffB + expSpdDiffA;

			if(expSpdDiff >= 0.2)
				expSpdDiff = 0.2;
			if(expSpdDiff <= -0.2)
				expSpdDiff = -0.2;

			spdExp = expSpdDiff + oldSpdCmdOutput;//expSpdDiff + oldSpdCmdOutput;
			spdExp = std::max(0.0, std::min(spdExp, decisionData.relative_speed_map));
			ROS_INFO("[Z.H][Speed_Regulation]:now spdExp: %f", spdExp);
			spdExp = 0.4 * spdExp + 0.6 * oldSpdExp;
			ROS_INFO("[Z.H][Speed_Regulation]:now1 spdExp: %f", spdExp);
			
			oldSpdExp = spdExp;
			
			spdTemp = spdExp - oldSpdCmd;
			if(spdTemp > 0.075)//0.075
				spdTemp = 0.075;
			if(spdTemp < -0.125)//-0.125
				spdTemp = -0.125;

			spdCmd = oldSpdCmd + spdTemp;
			oldSpdCmd = spdCmd;
			
			advisedSpeed = spdExp;
			if(advisedSpeed < 0.001)
				advisedSpeed = 0;			
			decisionData.full_stop_flag = 0;
			ROS_INFO_STREAM("[Z.H][Speed_Regulation]:\n" << 
			          " 1.distError: " << distError << "\n"
			          " 2.expSpdDiffB: " << expSpdDiffB << " \n"
			          " 3.expSpdDiffA: " << expSpdDiffA << " \n"
			          " 4.expSpdDiff: " << expSpdDiff << " \n"
			          " 5.spdExp: " << spdExp << "\n"
			          " 6.spdTemp: " << spdTemp << "\n"
			          " 7.spdCmd: " << spdCmd << "\n"
			          " 8.advisedSpeed: " << advisedSpeed*3.6 << "km/h\n");
			break;
		}
		case Emergent_Brake:
		{
			advisedSpeed = 0;
			decisionData.full_stop_flag = 1;
			break;
		}
		default: break;
	}

	oldFullStop = decisionData.full_stop_flag;
	oldSpdCmdOutput = advisedSpeed;

	oldDistError = distError;
	oldRelSpd = decisionData.relative_speed;

	decisionData.targetSpeed = advisedSpeed;
	ROS_INFO("[Z.H][getTargetSpeed][Main_State]: %d\n[final advised speed]: %f km/h.", Main_State, decisionData.targetSpeed*3.6);

	
	std::string path = "/home/a/Desktop/debug.txt";
	static std::ofstream fsDebug(path, std::ofstream::trunc);
	fsDebug << Main_State << " " << ACC_FOLLOW << " " << decisionData.obstacle_isValid << " " << decisionData.obstacle_dtc_min << " " << decisionData.targetSpeed*3.6 << " " << decisionData.velocity*3.6 << " " << oldFullStop << " " << decisionData.full_stop_flag << " " << decisionData.current_driving_mode << " " << decisionData.bottom_enable_switch << " " << decisionData.bottom_driving_state << " " << std::endl;
	
}


/*
void getTargetSpeed(DecisionData &decisionData, PostureData &postureData, LidarData &lidarData)
{
	double judgeSpeed = (decisionData.targetSpeed > MAX_SPEED) ? MAX_SPEED : decisionData.targetSpeed;
  	judgeSpeed = (decisionData.targetSpeed < MIN_SPEED) ? MIN_SPEED : decisionData.targetSpeed;
  	double advisedSpeed = judgeSpeed;
  	double advisedSpeedTakeOver = judgeSpeed;

	paramsAdjustByVehicleSpeed(decisionData);

	double tire_angle_feedback = global_feedback_steering_angle/WHEEL_TO_TIRE;
	double tire_angle_feedback_rad = tire_angle_feedback*M_PI/180;
	double current_v_front = postureData.imuData.velocity;//front wheel speed ::the previous conversion has been made
	ROS_INFO_STREAM("[Z.H][getTargetSpeed] now receive info:\n" << 
			          " 1.wheel steering angle feedback:: " << decisionData.current_steering_angle << " degree;\n"
			          " 2.tire angle feedback: " << tire_angle_feedback << " degree\n"
			          " 3.current front axis speed: " << current_v_front*3.6 << " km/h.");

	if(std::fabs(tire_angle_feedback) > 2)
	{
		double r_front = WHEELBASE/std::sin(tire_angle_feedback_rad);
		double r_back = r_front*(std::cos(tire_angle_feedback_rad));

		ROS_INFO("[Z.H]calculate 1.r_front: %f m  2.r_back: %f m.", r_front, r_back);
		Point circle_point;//center of circle
		circle_point.x = r_back;
		circle_point.y = -WHEELBASE;
	
		double angular_speed = current_v_front/(std::fabs(r_front));//rad/s
		ROS_INFO("[Z.H]current angular_speed:%f rad/s", angular_speed);
		double r_min = (std::fabs(r_back)) - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double r_max = (std::fabs(r_front)) + CAR_WIDTH + PREVIEW_SAFE_WIDTH;

		std::vector<double> v_ttc;
		if(!lidarData.obstacle_coordinates.empty() && (current_v_front > 0) && (angular_speed > 0) && (r_min > 0) && (r_max > 0))
		{
		    int len = lidarData.obstacle_coordinates.size();
		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        double r_temp = sqrt((p_x - circle_point.x)*(p_x - circle_point.x) + (p_y - circle_point.y)*(p_y - circle_point.y));
		        if(r_temp <= r_max && r_temp >= r_min){
		            double alpha = std::atan2(p_y + WHEELBASE, std::fabs(r_back - p_x));//rad
		            if(alpha > std::fabs(tire_angle_feedback_rad)){
		                double ttc = (alpha - std::fabs(tire_angle_feedback_rad))/angular_speed;
		                v_ttc.push_back(ttc);
		            }   
		        }
		    }

		    if(v_ttc.size() > 0)
		    {
		    	double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
			    ROS_INFO("[Z.H]when tire_angle_feedback is useful,now ttc_min: %f s",ttc_min);
			    if(ttc_min <= TTC_REDUCE_SPEED_TIME)
			    {
			        advisedSpeed = current_v_front + (-0.1)*MAX_DE_ACC;
			        if(advisedSpeed < 0.1){
			            advisedSpeed = 0.0;
			        }
			    }
			    if(ttc_min <= TTC_BRAKE_TIME){
			        advisedSpeed = 0.0;
			    }
			}    
		}
		else
		{
		    advisedSpeed = judgeSpeed;
		}
	}
	
	else//std::fabs(tire_angle_feedback)<2.0		
	{
		double min_x = 0.0 - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double max_x = 0.0 + CAR_WIDTH + PREVIEW_SAFE_WIDTH;
		double min_y = 0.0;
		double max_y = PREVIEW_SAFE_LENGTH;
		std::vector<double> v_ttc;
		
		if(!lidarData.obstacle_coordinates.empty() && current_v_front > 0) 
		{
		    int len = lidarData.obstacle_coordinates.size();
		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        if(p_x <= max_x && p_x >= min_x && p_y <= max_y && p_y >= min_y){
		        	ROS_INFO("[Z.H]observed area p_x: %f ; p_y: %f .", p_x, p_y);
		            double ttc = std::fabs(p_y)/current_v_front;
		            ROS_INFO("[Z.H]now in preview area obstacle to the bus distance is %f. and the arrived time is %f s", std::fabs(p_y), ttc);
		            v_ttc.push_back(ttc);
		        }
		    }
		    if(v_ttc.size() > 0)
		    {
		    	double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
			    ROS_INFO("[Z.H]when tire_angle_feedback is too small and is invalid, now ttc_min:%f",ttc_min);
			    if(ttc_min <= TTC_REDUCE_SPEED_TIME)
			    {
			        advisedSpeed = current_v_front + (-0.1)*MAX_DE_ACC;
			        if(advisedSpeed < 0.1){
			            advisedSpeed = 0.0;
			        }
			    }
			    if(ttc_min <= TTC_BRAKE_TIME)
			        advisedSpeed = 0.0;
		    }		    
		}
		else
		{
		    advisedSpeed = judgeSpeed;
		}
	}
	ROS_INFO("[Z.H]original judgeSpeed:%f km/h", judgeSpeed*3.6);
	ROS_INFO("[Z.H]NOW advisedSpeed:%f km/h", advisedSpeed*3.6);

  	//speed assignment 
	if(decisionData.b_takeOverEnable == false) 
	{
		decisionData.b_takingOver = false;
		if(advisedSpeed < judgeSpeed )
		{
			if (decisionData.targetSpeed > advisedSpeed)
			{
				decisionData.targetSpeed = advisedSpeed;
				ROS_INFO("[Z.H]speed limited because of obstacle~");
			}
		}
	}
	if(decisionData.b_takeOverEnable == true)
	{
		ROS_INFO("[Z.H]NOW currentpoint in roadmap is overtaking enabled~~");
		if(decisionData.b_takingOver == false)// not in overtaking
		{ 

		}
		else
		{

		}
	}
	
}

void getTargetSpeed(DecisionData &decisionData, PostureData &postureData, LidarData &lidarData)
{
	double d = 0;
	double c = 0;
	double judgeSpeed = (decisionData.targetSpeed > MAX_SPEED) ? MAX_SPEED : decisionData.targetSpeed;
  	judgeSpeed = (decisionData.targetSpeed < MIN_SPEED) ? MIN_SPEED : decisionData.targetSpeed;
  	double advisedSpeed = judgeSpeed;
  	double advisedSpeedTakeOver = judgeSpeed;

	paramsAdjustByVehicleSpeed(decisionData);

	double tire_angle_feedback = global_feedback_steering_angle/WHEEL_TO_TIRE;
	double tire_angle_feedback_rad = tire_angle_feedback*M_PI/180;
	double current_v_front = postureData.imuData.velocity;//front wheel speed ::the previous conversion has been made
	ROS_INFO_STREAM("[Z.H][getTargetSpeed] now receive info:\n" << 
			          " 1.wheel steering angle feedback:: " << decisionData.current_steering_angle << " degree;\n"
			          " 2.tire angle feedback: " << tire_angle_feedback << " degree\n"
			          " 3.current front axis speed: " << current_v_front*3.6 << " km/h \n"
			          " 4.now SAFE_DISTANCE_MIN: " << SAFE_DISTANCE_MIN << " m \n"
			          " 5.now PREVIEW_SAFE_LENGTH: " << PREVIEW_SAFE_LENGTH << " m \n"
			          " 6.now PREVIEW_SAFE_WIDTH: " << PREVIEW_SAFE_WIDTH << " m.");

	static double last_targetSpeed = 0;
	if(std::fabs(tire_angle_feedback) > 10)
	{
		double r_front = WHEELBASE/std::sin(tire_angle_feedback_rad);
		double r_back = r_front*(std::cos(tire_angle_feedback_rad));

		ROS_INFO("[Z.H]calculate 1.r_front: %f m  2.r_back: %f m.", r_front, r_back);
		Point circle_point;//center of circle
		circle_point.x = r_back;
		circle_point.y = -WHEELBASE;
	
		double angular_speed = current_v_front/(std::fabs(r_front));//rad/s
		double angular_speed_map = judgeSpeed/(std::fabs(r_front));//rad/s
		ROS_INFO("[Z.H]current angular_speed:%f rad/s; angular_speed_map: %f rad/s.", angular_speed, angular_speed_map);
		double r_min = (std::fabs(r_back)) - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double r_max = (std::fabs(r_front)) + CAR_WIDTH + PREVIEW_SAFE_WIDTH;

		std::vector<double> v_ttc;//time to collision
		std::vector<double> v_radian_difference;// rad difference
		if(!lidarData.obstacle_coordinates.empty() && (current_v_front > 0) && (angular_speed > 0) && (r_min > 0) && (r_max > 0))
		{
		    int len = lidarData.obstacle_coordinates.size();
		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        double r_temp = sqrt((p_x - circle_point.x)*(p_x - circle_point.x) + (p_y - circle_point.y)*(p_y - circle_point.y));
		        if(r_temp <= r_max && r_temp >= r_min){
		            double alpha = std::atan2(p_y + WHEELBASE, std::fabs(r_back - p_x));//rad
		            if(alpha > std::fabs(tire_angle_feedback_rad)){
		                double ttc = (alpha - std::fabs(tire_angle_feedback_rad))/angular_speed;
		                v_ttc.push_back(ttc);
		                v_radian_difference.push_back(alpha - std::fabs(tire_angle_feedback_rad));
		            }   
		        }
		    }

		    if(v_ttc.size() > 0 && v_radian_difference.size() > 0)
		    {
		    	double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
		    	double radian_min = *min_element(v_radian_difference.begin(), v_radian_difference.end());
			    ROS_INFO("[Z.H]when tire_angle_feedback is useful,now ttc_min: %f s, radian_min: %f rad", ttc_min, radian_min);
			    //---------state selection of speed into a finite state machine--------//
			    //state transition
			    switch(Main_State)
				{
					case Speed_Regulation:
					{
						double d_min = 0.1 * angular_speed * angular_speed + 0.2 * angular_speed + 2;	
						if(radian_min <= d_min || current_v_front < 0.28) //<1km/h
							Main_State = Emergent_Brake;
						break;
					}
					
					case Emergent_Brake:
					{
						if(radian_min > angular_speed_map * TTC_REDUCE_SPEED_TIME)
							Main_State = Speed_Regulation;
						break;
					}
			
					default: break;
				}
				//state output
				switch(Main_State)
				{
					case Speed_Regulation:
					{	
						double decelerate, v_min;

						v_min = std::min(current_v_front, last_targetSpeed);
						decelerate = v_min * K_TTC * (TTC_REDUCE_SPEED_TIME - ttc_min);

						if (decelerate > 0.1) 
							decelerate = 0.1;
						else if (decelerate < 0) 
							decelerate = 0;
						else;

						advisedSpeed = v_min - decelerate;
						decisionData.full_stop_flag = 0;

						break;
					}
					
					case Emergent_Brake:
					{
						advisedSpeed = 0;
						decisionData.full_stop_flag = 1;
						break;
					}
					default: break;
				}
			}
			else
			{
				Main_State = Speed_Regulation;
				decisionData.full_stop_flag = 0;

			}    
		}
		else
		{
			Main_State = Speed_Regulation;
			decisionData.full_stop_flag = 0;
		    //advisedSpeed = judgeSpeed;
		}
	}
	
	else//std::fabs(tire_angle_feedback)<2.0		
	{
		double min_x = 0.0 - CAR_WIDTH - PREVIEW_SAFE_WIDTH;
		double max_x = 0.0 + CAR_WIDTH + PREVIEW_SAFE_WIDTH;
		double min_y = 0.1;
		double max_y = PREVIEW_SAFE_LENGTH;
		std::vector<double> v_ttc;//time to collision
		std::vector<double> v_cd;//distance to collision
		
		if(!lidarData.obstacle_coordinates.empty() && current_v_front > 0) 
		{
		    int len = lidarData.obstacle_coordinates.size();
		    for(size_t i = 0; i < len; ++i)
		    {
		        double p_x = lidarData.obstacle_coordinates[i].x;
		        double p_y = lidarData.obstacle_coordinates[i].y;
		        if(p_x <= max_x && p_x >= min_x && p_y <= max_y && p_y >= min_y){
		        	ROS_INFO("[Z.H]observed area p_x: %f ; p_y: %f .", p_x, p_y);
		            double ttc = std::fabs(p_y)/current_v_front;
		            ROS_INFO("[Z.H]now in preview area obstacle to the bus distance is %f m. and the arrived time is %f s", std::fabs(p_y), ttc);
		            v_ttc.push_back(ttc);
		            v_cd.push_back(std::fabs(p_y));
		        }
		    }
		    if(v_ttc.size() > 0 && v_cd.size() > 0)
		    {
		    	double ttc_min = *min_element(v_ttc.begin(), v_ttc.end());
		    	double cd_min = *min_element(v_cd.begin(), v_cd.end());
			    ROS_INFO("[Z.H]when tire_angle_feedback is too small and is invalid, now ttc_min: %f s; cd_min: %f m", ttc_min, cd_min);
			    d = ttc_min;
			    c = cd_min;
			    //---------state selection of speed into a finite state machine--------//
			    //state transition
			    switch(Main_State)
				{
					case Speed_Regulation:
					{		
						if(cd_min <= SAFE_DISTANCE_MIN || current_v_front < 0.28) //<1km/h
							Main_State = Emergent_Brake;
						break;
					}
					
					case Emergent_Brake:
					{
						if(cd_min > judgeSpeed * TTC_REDUCE_SPEED_TIME)
							Main_State = Speed_Regulation;
						break;
					}
			
					default: break;
				}
				//state output
				switch(Main_State)
				{
					case Speed_Regulation:
					{	
						double decelerate, v_min;

						v_min = std::min(current_v_front, last_targetSpeed);
						decelerate = v_min * K_TTC * (TTC_REDUCE_SPEED_TIME - ttc_min);

						if (decelerate > 0.1) 
							decelerate = 0.1;
						else if (decelerate < 0) 
							decelerate = 0;
						else;

						advisedSpeed = v_min - decelerate;
						if (advisedSpeed < 0.1)
						{
							advisedSpeed = 0;
							decisionData.full_stop_flag = 1;
						}
						std::cout << "Speed_Regulation: advisedSpeed:" << advisedSpeed << std::endl; 
						decisionData.full_stop_flag = 0;

						break;
					}
					
					case Emergent_Brake:
					{
						std::cout << "Emergent_Brake" << std::endl;
						advisedSpeed = 0;
						decisionData.full_stop_flag = 1;
						break;
					}
					default: break;
				}
		    }
		    else
			{
				Main_State = Speed_Regulation;
				decisionData.full_stop_flag = 0;
				advisedSpeed = judgeSpeed;
			} 

		}
		else
		{
			Main_State = Speed_Regulation;
			decisionData.full_stop_flag = 0;
		    advisedSpeed = judgeSpeed;
		}
	}
	ROS_INFO("[Z.H]original judgeSpeed:%f km/h", judgeSpeed*3.6);
	ROS_INFO("[Z.H]NOW advisedSpeed:%f km/h", advisedSpeed*3.6);

  	//speed assignment 
	if(decisionData.b_takeOverEnable == false) 
	{
		decisionData.b_takingOver = false;
		if(advisedSpeed < judgeSpeed )
		{
			decisionData.targetSpeed = advisedSpeed;
			ROS_INFO("[Z.H]speed limited because of obstacle~");
			
		}
	}
	if(decisionData.b_takeOverEnable == true)
	{
		ROS_INFO("[Z.H]NOW currentpoint in roadmap is overtaking enabled~~");
		if(decisionData.b_takingOver == false)// not in overtaking
		{ 

		}
		else
		{

		}
	}
	last_targetSpeed = decisionData.targetSpeed;
	std::string path = "/home/a/Desktop/debug.txt";
	static std::ofstream fsDebug(path, std::ofstream::trunc);
	fsDebug << decisionData.targetSpeed << " " << decisionData.velocity << " " << decisionData.full_stop_flag << " " << Main_State << " " << d << " " << c << std::endl;
	
}
*/