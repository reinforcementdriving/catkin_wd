/**
 * @file: perception_display_node.cpp
 * @author: Z.H
 * @date: 2019.05.9
 */
#include <ros/ros.h>
#include "perception_display/perception_display.h"


int main(int argc, char *argv[])
{
	ros::init(argc, argv, "perception_display_node");

    PerceptionDisplay pd;

	return 0;
}