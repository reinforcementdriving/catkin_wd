/**
 * @file: lidar_perception.cpp
 * @author: Z.H
 * @date: 2019.05.9
 */
#include "lidar_perception/lidar_perception.h"


LidarPerception::LidarPerception():
					               left_transfor_cloud_ptr_(new PointCloud()),
					              right_transfor_cloud_ptr_(new PointCloud()),
			    left_cloud_(new PointCloud()), right_cloud_(new PointCloud()),
			  point_cloud_(new PointCloud()), center_cloud_(new PointCloud()){
	ROS_INFO("[Z.H]begin to lidar_perception!");
}

LidarPerception::~LidarPerception() {
	ros::shutdown();
}

Eigen::Affine3f LidarPerception::getTransformMat(const std::vector<double> &params)
{
	Eigen::Affine3f result = Eigen::Affine3f::Identity();

	result.translation() << params[0], params[1], params[2];

	result.rotate (Eigen::AngleAxisf(params[3] * PI_OVER_180, Eigen::Vector3f::UnitX())
	             * Eigen::AngleAxisf(params[4] * PI_OVER_180, Eigen::Vector3f::UnitY())
	             * Eigen::AngleAxisf(params[5] * PI_OVER_180, Eigen::Vector3f::UnitZ()));

	return result;
}

void LidarPerception::init()
{
	nh_.getParam("/lidar_perception/left_lidar_topic", left_lidar_topic_);
	nh_.getParam("/lidar_perception/right_lidar_topic", right_lidar_topic_);
	nh_.getParam("/lidar_perception/center_lidar_topic", center_lidar_topic_);
	nh_.getParam("/lidar_perception/grid_map_topic", grid_map_topic_);
	nh_.getParam("/lidar_perception/heart_topic", heart_topic_);

	nh_.getParam("/lidar_perception/roi/x_min", x_min_);
	nh_.getParam("/lidar_perception/roi/y_min", y_min_);
	nh_.getParam("/lidar_perception/roi/z_min", z_min_);
    nh_.getParam("/lidar_perception/roi/x_max", x_max_);
    nh_.getParam("/lidar_perception/roi/y_max", y_max_);
    nh_.getParam("/lidar_perception/roi/z_max", z_max_);

    nh_.getParam("/lidar_perception/map_resolution", map_resolution_);
    nh_.getParam("/lidar_perception/car_info/car_width", car_width_);
    nh_.getParam("/lidar_perception/car_info/car_length", car_length_);

	nh_.param("/lidar_perception/trans_params/left", 
		                left_trans_params_, std::vector<double>(0));
	nh_.param("/lidar_perception/trans_params/right", 
		               right_trans_params_, std::vector<double>(0));

	if(left_trans_params_.empty() || right_trans_params_.empty())
    	ROS_ERROR("[Z.H]lidar trans_params load failure!!!");

    left_lidar_sub_ = nh_.subscribe(left_lidar_topic_, 1, 
    	              &LidarPerception::subLeftCallback, this);
    right_lidar_sub_ = nh_.subscribe(right_lidar_topic_, 1, 
    	              &LidarPerception::subRightCallback, this);

    center_lidar_pub_ = nh_.advertise<sensor_msgs::PointCloud2>(center_lidar_topic_, 10, this);
    grid_map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>(grid_map_topic_, 10, this);
    left_grid_map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("/left/gridmap", 10, this);
    right_grid_map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("/right/gridmap", 10, this);
    heart_pub_ = nh_.advertise<std_msgs::UInt32>(heart_topic_, 1, this);
    

    // get transform_mat
	left_transform_mat_ = getTransformMat(left_trans_params_);
	right_transform_mat_ = getTransformMat(right_trans_params_);
	std::cout << "left_transform_mat:" << std::endl << left_transform_mat_.matrix() << std::endl;
	std::cout << "right_transform_mat:" << std::endl << right_transform_mat_.matrix() << std::endl;

	//set map roi value
	//In the coordinate system conversion, the lidar coordinate system should be converted to the Car coordinate system of the local vehicle, x to the right, y to the front.
	map_x_min_ = 0;
	map_x_max_ = (int)((y_max_ - y_min_)/map_resolution_);
	map_y_min_ = 0;
	map_y_max_ = (int)((x_max_ - x_min_)/map_resolution_);
}


void LidarPerception::subLeftCallback(const sensor_msgs::PointCloud2::ConstPtr &msg)
{
	pcl::fromROSMsg(*msg, *left_cloud_);
    //ROS_INFO("left point size %ld ", left_cloud_->points.size());
}

void LidarPerception::subRightCallback(const sensor_msgs::PointCloud2::ConstPtr &msg)
{
	pcl::fromROSMsg(*msg, *right_cloud_);
    //ROS_INFO("right point size %ld ", right_cloud_->points.size());
}

void LidarPerception::makeGridMap(const PointCloudPtr &cloudtogrid)
{
	//ROS_INFO("begin to make grid map!!!");
	nav_msgs::OccupancyGrid map;
	nav_msgs::OccupancyGrid map_left;
	nav_msgs::OccupancyGrid map_right;
    
	map.header.frame_id = "base_link";
  	map.header.stamp = ros::Time::now();
  	map_left.header.frame_id = "base_link";
  	map_left.header.stamp = ros::Time::now();
  	map_right.header.frame_id = "base_link";
  	map_right.header.stamp = ros::Time::now();

  	int map_left_size = 16 * 120;//4m * 30m
  	map_left.info.resolution = map_resolution_;
	map_left.info.width = 16;
	map_left.info.height = 120;
	map_left.info.origin.position.x = (-4 - (car_width_/2));
	map_left.info.origin.position.y = -20;//In the coordinate system conversion, the lidar coordinate system should be converted to the Car coordinate system of the local vehicle, x to the right, y to the front.
	map_left.info.origin.position.z = 0;
	map_left.data.resize(map_left_size, 0);

	int map_right_size = 16 * 80;//4m * 20m
  	map_right.info.resolution = map_resolution_;
	map_right.info.width = 16;
	map_right.info.height = 80;
	map_right.info.origin.position.x = (0 + (car_width_/2));
	map_right.info.origin.position.y = -10;//In the coordinate system conversion, the lidar coordinate system should be converted to the Car coordinate system of the local vehicle, x to the right, y to the front.
	map_right.info.origin.position.z = 0;
	map_right.data.resize(map_right_size, 0);



	int map_width = (int)(map_x_max_ - map_x_min_);//80 pix
	int map_height = (int)(map_y_max_ - map_y_min_);//240 pix
	int map_size = map_width * map_height;
	map.info.resolution = map_resolution_;
	map.info.width = map_width;
	map.info.height = map_height;
	map.info.origin.position.x = y_min_;
	map.info.origin.position.y = x_min_;//In the coordinate system conversion, the lidar coordinate system should be converted to the Car coordinate system of the local vehicle, x to the right, y to the front.
	map.info.origin.position.z = 0;
	map.data.resize(map_size, 0);
	float x_temp_min = -20.0;
	float x_temp_max = 80.0;
	float y_temp_min = -15.0;
	float y_temp_max = 15.0;
	float z_temp_min = -1.5;
	float z_temp_max = 4;

	
	// NO.1
	if(!cloudtogrid->points.empty()) {
		for(size_t i = 0; i < cloudtogrid->points.size(); i++) 
		{
			if(cloudtogrid->points[i].x < x_temp_min || cloudtogrid->points[i].x > x_temp_max ||
			   cloudtogrid->points[i].y < y_temp_min || cloudtogrid->points[i].y > y_temp_max ||
			   cloudtogrid->points[i].z < z_temp_min || cloudtogrid->points[i].z > z_temp_max ||
			   								  !pcl_isfinite(cloudtogrid->points[i].x) || 
			   								  !pcl_isfinite(cloudtogrid->points[i].y) ||
			   								  !pcl_isfinite(cloudtogrid->points[i].z)) {
				continue;
			}
			else if((cloudtogrid->points[i].x <= 0.2) && (cloudtogrid->points[i].x >= (-car_length_- 0.2)) &&
					(cloudtogrid->points[i].y <= (car_width_/2 + 0.2)) && (cloudtogrid->points[i].y >= (- car_width_/2 - 0.2))) {
				continue;
			}
			else {
				//save the filter pointcloud
				center_cloud_->points.push_back(cloudtogrid->points[i]);

				//make gridmap
				if(cloudtogrid->points[i].x >= x_min_ && cloudtogrid->points[i].x <= x_max_ &&
				   cloudtogrid->points[i].y >= y_min_ && cloudtogrid->points[i].y <= y_max_ &&
				   cloudtogrid->points[i].z >= z_min_ && cloudtogrid->points[i].z <= z_max_)
				{
					int map_x = (int)(-(cloudtogrid->points[i].y - y_max_)/map_resolution_);
					int map_y = (int)((cloudtogrid->points[i].x - x_min_)/map_resolution_);
					int index = map_y * map_width + map_x;
					if(index < map_size && index >= 0 && map_x >= 0 && map_y >= 0) {
						map.data[index] += 1; 
					}
				}
				//make left gridmap
				if(cloudtogrid->points[i].x >= -20 && cloudtogrid->points[i].x <= 10 &&
				   cloudtogrid->points[i].y >= (car_width_/2) && cloudtogrid->points[i].y <= ((car_width_/2) + 4) &&
				   cloudtogrid->points[i].z >= z_min_ && cloudtogrid->points[i].z <= z_max_)
				{
					int map_left_x = (int)(-(cloudtogrid->points[i].y - ((car_width_/2) + 4))/map_resolution_);
					int map_left_y = (int)((cloudtogrid->points[i].x - (-20))/map_resolution_);
					int index = map_left_y * 16 + map_left_x;
					if(index < map_left_size && index >= 0 && map_left_x >= 0 && map_left_y >= 0) {
						map_left.data[index] += 1; 
					}
				}
				//make right gridmap
				if(cloudtogrid->points[i].x >= -10 && cloudtogrid->points[i].x <= 10 &&
				   cloudtogrid->points[i].y >= (-4-(car_width_/2)) && cloudtogrid->points[i].y <= -(car_width_/2) &&
				   cloudtogrid->points[i].z >= z_min_ && cloudtogrid->points[i].z <= z_max_)
				{
					int map_right_x = (int)(-(cloudtogrid->points[i].y - (-(car_width_/2)))/map_resolution_);
					int map_right_y = (int)((cloudtogrid->points[i].x - (-10))/map_resolution_);
					int index = map_right_y * 16 + map_right_x;
					if(index < map_right_size && index >= 0 && map_right_x >= 0 && map_right_y >= 0) {
						map_right.data[index] += 1; 
					}
				}
			}
		}
		for(size_t j = 0; j < map_size; j++)
	    {
	        if(map.data[j] >= 2) {
				map.data[j] = 100;          
	        }
	        else {
	        	map.data[j] = 0;
	        }
	    }
	    for(size_t j = 0; j < map_left_size; j++)
	    {
	        if(map_left.data[j] >=  5) {
				map_left.data[j] = 100;          
	        }
	        else {
	        	map_left.data[j] = 0;
	        }
	    }
	    for(size_t j = 0; j < map_right_size; j++)
	    {
	        if(map_right.data[j] >=  5) {
				map_right.data[j] = 100;          
	        }
	        else {
	        	map_right.data[j] = 0;
	        }
	    }
	}
	/*
	//NO.2
	std::vector<std::vector<double> > point_z(map_size);
	if(!cloudtogrid->points.empty()) {
		#pragma omp for
		for(size_t i = 0; i < cloudtogrid->points.size(); i++) 
		{
			if(cloudtogrid->points[i].x < x_temp_min || cloudtogrid->points[i].x > x_temp_max ||
			   cloudtogrid->points[i].y < y_temp_min || cloudtogrid->points[i].y > y_temp_max ||
			   cloudtogrid->points[i].z < z_min_ || cloudtogrid->points[i].z > z_max_ ||
			   								  !pcl_isfinite(cloudtogrid->points[i].x) || 
			   								  !pcl_isfinite(cloudtogrid->points[i].y) ||
			   								  !pcl_isfinite(cloudtogrid->points[i].z)) {
				continue;
			}
			else if((cloudtogrid->points[i].x <= 0.2) && (cloudtogrid->points[i].x >= (-car_length_- 0.2)) &&
					(cloudtogrid->points[i].y <= (car_width_/2 + 0.3)) && (cloudtogrid->points[i].y >= (- car_width_/2 - 0.3))) {
				continue;
			}
			else {
				//save the filter pointcloud
				//std::cout << " x: y: z: = " << cloudtogrid->points[i].x << " " << cloudtogrid->points[i].y << " " << cloudtogrid->points[i].z << std::endl;
				center_cloud_->points.push_back(cloudtogrid->points[i]);
				//calculate the index of the pointcloud in the gridmap
				if(cloudtogrid->points[i].x >= x_min_ && cloudtogrid->points[i].x <= x_max_ &&
				   cloudtogrid->points[i].y >= y_min_ && cloudtogrid->points[i].y <= y_max_){
					int map_x = (int)(-(cloudtogrid->points[i].y - y_max_)/map_resolution_);
					int map_y = (int)((cloudtogrid->points[i].x - x_min_)/map_resolution_);
					int index = map_y * map_width + map_x;
					if(index < map_size && index >= 0 && map_x >= 0 && map_y >= 0) {
						point_z[index].push_back(cloudtogrid->points[i].z);
					}
				}
			}
		}
		#pragma omp for
		for(size_t j = 0; j < map_size; j++)
	    {
	    	std::vector<double> v = point_z[j];
	    	if(v.empty()) {
	    		map.data[j] = 0;
	    	}
	    	else {
	    		//std::cout << "Max:" << *max_element(v.begin(), v.end()) << "  Min:" << *min_element(v.begin(), v.end()) << std::endl;
	    		double value = (*max_element(v.begin(), v.end())) - (*min_element(v.begin(), v.end()));
	    		//std::cout << "value:" << value << std::endl;
	    		if(value >= 0.13) {
	    			map.data[j] = 100;
	    		}
	    		else {
	        		map.data[j] = 0;
	        	}
	    	}	        
	    }
	}
    */
	grid_map_pub_.publish(map);
	left_grid_map_pub_.publish(map_left);
	right_grid_map_pub_.publish(map_right);
}

void LidarPerception::doListening()
{
    ros::Rate loop_rate(25);

    while(nh_.ok()) {

        ros::spinOnce();

        /*-----------------------------main loop--------------------------------*/
        //1. Converting the pointcloud of the left and right lidar coordinate system to car body coordinate system
	    pcl::transformPointCloud(*left_cloud_, *left_transfor_cloud_ptr_, left_transform_mat_);
	    pcl::transformPointCloud(*right_cloud_, *right_transfor_cloud_ptr_, right_transform_mat_);

	    point_cloud_->points.clear();
	    point_cloud_->points.insert(point_cloud_->points.end(),
	    				  left_transfor_cloud_ptr_->points.begin(),left_transfor_cloud_ptr_->points.end());
    	point_cloud_->points.insert(point_cloud_->points.end(),
    		             right_transfor_cloud_ptr_->points.begin(),right_transfor_cloud_ptr_->points.end());

    	std_msgs::UInt32 heart;
	    heart.data = point_cloud_->points.size();
		heart_pub_.publish(heart);
		ROS_INFO("[Z.H]pub point_cloud_ size: %ld ", point_cloud_->points.size());
		
	    //2. Constructing 2-D grid map and publish
	    center_cloud_->clear();
        makeGridMap(point_cloud_);
        ROS_INFO("[Z.H]pub center_cloud size: %ld ", center_cloud_->points.size());
        
		//3. Publish fusion to center pointcloud
		if(!center_cloud_->points.empty()) {
			sensor_msgs::PointCloud2 centerMsg;
	        pcl::toROSMsg(*center_cloud_, centerMsg);
	        centerMsg.header.frame_id = "base_link";
	        centerMsg.header.stamp = ros::Time::now();        
	        center_lidar_pub_.publish(centerMsg);
	    }

        loop_rate.sleep();           
    }
}

